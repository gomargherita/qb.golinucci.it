<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Activitylog\LogOptions;
use Spatie\Activitylog\Traits\LogsActivity;

class Account extends Model
{

    use HasFactory, LogsActivity;

    // https://spatie.be/docs/laravel-permission/v5/basic-usage/teams-permissions
    public static function boot()
    {
        parent::boot();

        // TODO non funziona poiché presuppone che esista già l'utente, e nella fase di sviluppo prima di crea l'account e poi il set utenti. 
        // L'utente stesso per esistere deve avere un account id assegnato... sembra una logica circolare da cui non si esce
        // here assign this team to a global user with global default role
        // self::created(function ($model) {
        //     // get session account_id for restore it later
        //     $session_account_id = getPermissionsTeamId();
        //     var_dump($session_account_id);
        //     // set actual new account_id to package instance
        //     setPermissionsTeamId($model);
        //     // get the admin user and assign roles/permissions on new team model
        //     User::find(1)->assignRole(Role::ROLE_SUPERADMIN);
        //     // restore session account_id to package instance
        //     setPermissionsTeamId($session_account_id);
        // });
    }

    public function users()
    {
        return $this->hasMany(User::class);
    }

    public function products()
    {
        return $this->hasMany(Product::class);
    }

    public function carts()
    {
        return $this->hasManyThrough(Cart::class, User::class);
    }

    public function clientDetails()
    {
        return $this->hasManyThrough(ClientDetail::class, User::class);
    }

    // TODO prevedere di assegnare i tipi prodotto all'account
    // public function productTypes()
    // {
    //     return $this->hasMany(ProductType::class);
    // }

    public function roles()
    {
        return $this->hasMany(Role::class);
    }

    public function getActivitylogOptions(): LogOptions
    {
        return LogOptions::defaults()
            ->logOnly(['name']);
    }
}

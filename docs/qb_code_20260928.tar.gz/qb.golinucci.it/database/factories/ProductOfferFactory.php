<?php

namespace Database\Factories;

use App\Models\ConditionalField;
use App\Models\Contract;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

class ProductOfferFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $products_number = Product::count();
        $contracts_number = Contract::count();
        //$conditional_fields_number = ConditionalField::count();

        return [
            'name' => $this->faker->unique()->domainName(),
            'sku' => $this->faker->ean13(),
            'product_id' => $this->faker->numberBetween(1, $products_number),
            'contract_id' => $this->faker->numberBetween(1, $contracts_number),
            'total_payable' => $this->faker->numberBetween(0, 30000),
            'admin_fee' => $this->faker->numberBetween(0, 30000),
            'gross_premium' => $this->faker->numberBetween(0, 30000),
            'tax' => $this->faker->numberBetween(0, 30000),
            'net_premium' => $this->faker->numberBetween(0, 30000),
            'accessory' => $this->faker->numberBetween(0, 30000),
            'net_plus_access_premium' => $this->faker->numberBetween(0, 30000),
            'description' => $this->faker->paragraph(3),
            'indemnity_limit' => $this->faker->numberBetween(0, 10000000),
            'indemnity_limit_patrimonial' => $this->faker->numberBetween(0, 10000000),
            'flag_prev_2022' => 0,
            'months' => $this->faker->numberBetween(1, 12),
            'active' => $this->faker->boolean(),
        ];
    }
}

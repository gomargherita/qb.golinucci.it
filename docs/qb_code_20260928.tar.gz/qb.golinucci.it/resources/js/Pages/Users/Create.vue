<template>
  <div>
    <Head title="Create User" />
    <h1 class="mb-8 text-3xl font-bold">
      <Link class="text-primary hover:text-secondary-400" :href="route('users')">{{
        __("Users")
      }}</Link>
      <span class="text-gray font-medium">/</span>{{ __("Create") }}
    </h1>
    <div class="bg-white rounded-md shadow overflow-hidden">
      <form @submit.prevent="store">
        <div class="flex flex-wrap -mb-8 -mr-6 p-8">
          <text-input
            v-model="form.first_name"
            :error="form.errors.first_name"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="First Name"
          />
          <text-input
            v-model="form.last_name"
            :error="form.errors.last_name"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="Last Name"
          />
          <text-input
            v-model="form.email"
            :error="form.errors.email"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="Email"
          />
          <text-input
            v-model="form.password"
            :error="form.errors.password"
            class="pb-8 pr-6 w-full lg:w-1/2"
            type="password"
            autocomplete="new-password"
            label="Password"
          />
          <select-input
            v-if="this.$page.props.auth.user.is_superadmin"
            v-model="form.owner"
            :error="form.errors.owner"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="Admin"
          >
            <option :value="true">{{ __("Yes") }}</option>
            <option :value="false">{{ __("No") }}</option>
          </select-input>
          <select-input
            v-model="form.new_client"
            :error="form.errors.new_client"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="New client"
          >
            <option :value="true">{{ __("Yes") }}</option>
            <option :value="false">{{ __("No") }}</option>
          </select-input>
          <select-input
            v-model="form.role"
            :error="form.errors.role"
            class="pb-8 pr-6 w-full lg:w-1/2"
            label="Role"
          >
            <option
              v-for="role in roles"
              :value="role.name"
              :selected="role.name == form.role"
            >
              {{ __(role.name) }}
            </option>
          </select-input>
          <file-input
            v-model="form.photo"
            :error="form.errors.photo"
            class="pb-8 pr-6 w-full lg:w-1/2"
            type="file"
            accept="image/*"
            label="Photo"
          />
        </div>
        <div
          class="flex items-center justify-end px-8 py-4 bg-gray-50 border-t border-gray-100"
        >
          <loading-button :loading="form.processing" class="btn-gol-primary" type="submit"
            >{{ __("Create") }} {{ __("User") }}</loading-button
          >
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import Layout from "@/Shared/Layouts/Layout";
import FileInput from "@/Shared/FileInput";
import TextInput from "@/Shared/TextInput";
import SelectInput from "@/Shared/SelectInput";
import LoadingButton from "@/Shared/LoadingButton";

export default {
  components: {
    FileInput,
    LoadingButton,
    SelectInput,
    TextInput,
  },
  layout: Layout,
  props: {
    roles: Array,
  },
  remember: "form",
  data() {
    return {
      form: this.$inertia.form({
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        owner: false,
        new_client: false,
        role: "",
        photo: null,
      }),
    };
  },
  methods: {
    store() {
      this.form.post("/admin/users");
    },
  },
};
</script>

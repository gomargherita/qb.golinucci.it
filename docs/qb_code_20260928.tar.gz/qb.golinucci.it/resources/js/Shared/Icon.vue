<template>
  <svg
    v-if="name === 'cheveron-down'"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
  >
    <path
      d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
    />
  </svg>
  <svg
    v-else-if="name === 'cheveron-right'"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
  >
    <polygon
      points="12.95 10.707 13.657 10 8 4.343 6.586 5.757 10.828 10 6.586 14.243 8 15.657 12.95 10.707"
    />
  </svg>
  <svg
    v-else-if="name === 'products'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      fill-rule="evenodd"
      d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z"
      clip-rule="evenodd"
    />
  </svg>
  <svg
    v-else-if="name === 'dashboard'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      fill-rule="evenodd"
      d="M5 3a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2V5a2 2 0 00-2-2H5zm9 4a1 1 0 10-2 0v6a1 1 0 102 0V7zm-3 2a1 1 0 10-2 0v4a1 1 0 102 0V9zm-3 3a1 1 0 10-2 0v1a1 1 0 102 0v-1z"
      clip-rule="evenodd"
    />
  </svg>
  <svg
    v-else-if="name === 'office'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
    <path
      fill-rule="evenodd"
      d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3zm-3 4a1 1 0 100 2h.01a1 1 0 100-2H7zm3 0a1 1 0 100 2h3a1 1 0 100-2h-3z"
      clip-rule="evenodd"
    />
  </svg>
  <svg
    v-else-if="name === 'printer'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      fill-rule="evenodd"
      d="M5 4v3H4a2 2 0 00-2 2v3a2 2 0 002 2h1v2a2 2 0 002 2h6a2 2 0 002-2v-2h1a2 2 0 002-2V9a2 2 0 00-2-2h-1V4a2 2 0 00-2-2H7a2 2 0 00-2 2zm8 0H7v3h6V4zm0 8H7v4h6v-4z"
      clip-rule="evenodd"
    />
  </svg>
  <svg
    v-else-if="name === 'mail'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
    <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
  </svg>
  <svg
    v-else-if="name === 'phone'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-5 w-5"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"
    />
  </svg>
  <svg
    v-else-if="name === 'external-link'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      d="M11 3a1 1 0 100 2h2.586l-6.293 6.293a1 1 0 101.414 1.414L15 6.414V9a1 1 0 102 0V4a1 1 0 00-1-1h-5z"
    />
    <path
      d="M5 5a2 2 0 00-2 2v8a2 2 0 002 2h8a2 2 0 002-2v-3a1 1 0 10-2 0v3H5V7h3a1 1 0 000-2H5z"
    />
  </svg>

  <svg
    v-else-if="name === 'trash'"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 20 20"
  >
    <path
      d="M6 2l2-2h4l2 2h4v2H2V2h4zM3 6h14l-1 14H4L3 6zm5 2v10h1V8H8zm3 0v10h1V8h-1z"
    />
  </svg>
  <svg
    v-else-if="name === 'users'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z"
    />
  </svg>
  <svg
    v-else-if="name === 'roles'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z"
    />
  </svg>
  <svg
    v-else-if="name === 'en'"
    enable-background="new 0 0 512 512"
    version="1.1"
    viewBox="0 0 512 512"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="256" cy="256" r="256" fill="#F0F0F0" />
    <g fill="#0052B4">
      <path
        d="m52.92 100.14c-20.109 26.163-35.272 56.318-44.101 89.077h133.18l-89.077-89.077z"
      />
      <path
        d="m503.18 189.22c-8.829-32.758-23.993-62.913-44.101-89.076l-89.075 89.076h133.18z"
      />
      <path
        d="m8.819 322.78c8.83 32.758 23.993 62.913 44.101 89.075l89.074-89.075h-133.18z"
      />
      <path
        d="m411.86 52.921c-26.163-20.109-56.317-35.272-89.076-44.102v133.18l89.076-89.075z"
      />
      <path
        d="m100.14 459.08c26.163 20.109 56.318 35.272 89.076 44.102v-133.18l-89.076 89.074z"
      />
      <path
        d="M189.217,8.819c-32.758,8.83-62.913,23.993-89.075,44.101l89.075,89.075V8.819z"
      />
      <path
        d="m322.78 503.18c32.758-8.83 62.913-23.993 89.075-44.101l-89.075-89.075v133.18z"
      />
      <path
        d="m370 322.78l89.075 89.076c20.108-26.162 35.272-56.318 44.101-89.076h-133.18z"
      />
    </g>
    <g fill="#D80027">
      <path
        d="m509.83 222.61h-220.44v-220.44c-10.931-1.423-22.075-2.167-33.392-2.167-11.319 0-22.461 0.744-33.391 2.167v220.44h-220.44c-1.423 10.931-2.167 22.075-2.167 33.392 0 11.319 0.744 22.461 2.167 33.391h220.44v220.44c10.931 1.423 22.073 2.167 33.392 2.167 11.317 0 22.461-0.743 33.391-2.167v-220.44h220.44c1.423-10.931 2.167-22.073 2.167-33.392 0-11.317-0.744-22.461-2.167-33.391z"
      />
      <path
        d="m322.78 322.78l114.24 114.24c5.254-5.252 10.266-10.743 15.048-16.435l-97.802-97.802h-31.482v1e-3z"
      />
      <path
        d="m189.22 322.78h-2e-3l-114.24 114.24c5.252 5.254 10.743 10.266 16.435 15.048l97.802-97.804v-31.479z"
      />
      <path
        d="m189.22 189.22v-2e-3l-114.24-114.24c-5.254 5.252-10.266 10.743-15.048 16.435l97.803 97.803h31.481z"
      />
      <path
        d="m322.78 189.22l114.24-114.24c-5.252-5.254-10.743-10.266-16.435-15.047l-97.802 97.803v31.482z"
      />
    </g>
  </svg>
  <svg
    v-else-if="name === 'it'"
    enable-background="new 0 0 512 512"
    version="1.1"
    viewBox="0 0 512 512"
    xml:space="preserve"
    xmlns="http://www.w3.org/2000/svg"
  >
    <mask id="a"><circle cx="256" cy="256" r="256" fill="#fff" /></mask>
    <g mask="url(#a)">
      <path fill="#eee" d="M167 0h178l25.9 252.3L345 512H167l-29.8-253.4z" />
      <path fill="#6da544" d="M0 0h167v512H0z" />
      <path fill="#d80027" d="M345 0h167v512H345z" />
    </g>
    <div xmlns="" id="syno-nsc-ext-comp-1008" class="x-tip-invalid">
      <div xmlns="http://www.w3.org/2000/svg" class="x-tip-invalid-tl">
        <div class="x-tip-invalid-tr">
          <div class="x-tip-invalid-tc">
            <div
              xmlns=""
              class="x-tip-invalid-header x-unselectable"
              id="syno-nsc-ext-gen4"
            >
              <span
                xmlns="http://www.w3.org/2000/svg"
                class="x-tip-invalid-header-text"
              />
            </div>
          </div>
        </div>
      </div>
      <div class="x-tip-invalid-bwrap" id="syno-nsc-ext-gen5">
        <div xmlns="http://www.w3.org/2000/svg" class="x-tip-invalid-ml">
          <div class="x-tip-invalid-mr">
            <div class="x-tip-invalid-mc" id="syno-nsc-ext-gen8">
              <div xmlns="" class="x-tip-invalid-body" id="syno-nsc-ext-gen6" />
            </div>
          </div>
        </div>
        <div
          xmlns="http://www.w3.org/2000/svg"
          class="x-tip-invalid-bl"
          id="syno-nsc-ext-gen7"
        >
          <div class="x-tip-invalid-br"><div class="x-tip-invalid-bc" /></div>
        </div>
      </div>
    </div>
  </svg>
  <svg
    v-else-if="name === 'facebook-icon'"
    id="facebook-circular-logo"
    xmlns="http://www.w3.org/2000/svg"
    width="43.046"
    height="42.867"
    viewBox="0 0 43.046 42.867"
  >
    <path
      id="Tracciato_60"
      data-name="Tracciato 60"
      d="M21.523.349a21.511,21.511,0,0,0-3.59,42.723V26.362H12.741V20.349h5.192V15.916c0-5.145,3.142-7.948,7.732-7.948A42.848,42.848,0,0,1,30.3,8.2v5.377l-3.183,0c-2.5,0-2.977,1.186-2.977,2.926v3.838H30.1l-.777,6.013H24.141V43.216A21.513,21.513,0,0,0,21.523.349Z"
      transform="translate(0 -0.349)"
    />
  </svg>
  <svg
    v-else-if="name === 'twitter-icon'"
    xmlns="http://www.w3.org/2000/svg"
    width="44.331"
    height="44.331"
    viewBox="0 0 44.331 44.331"
  >
    <path
      id="twitter"
      d="M22.166,0A22.166,22.166,0,1,0,44.331,22.166,22.168,22.168,0,0,0,22.166,0ZM32.286,17.282q.015.327.015.658A14.377,14.377,0,0,1,17.825,32.416h0a14.4,14.4,0,0,1-7.8-2.285,10.348,10.348,0,0,0,1.214.07,10.208,10.208,0,0,0,6.319-2.178,5.093,5.093,0,0,1-4.753-3.534,5.071,5.071,0,0,0,2.3-.087,5.089,5.089,0,0,1-4.082-4.987c0-.023,0-.044,0-.065a5.053,5.053,0,0,0,2.3.636,5.092,5.092,0,0,1-1.575-6.792A14.444,14.444,0,0,0,22.239,18.51a5.09,5.09,0,0,1,8.67-4.64,10.2,10.2,0,0,0,3.231-1.235A5.107,5.107,0,0,1,31.9,15.449a10.147,10.147,0,0,0,2.922-.8,10.339,10.339,0,0,1-2.538,2.635Zm0,0"
    />
  </svg>
  <svg
    v-else-if="name === 'linkedin-icon'"
    xmlns="http://www.w3.org/2000/svg"
    width="44.605"
    height="44.605"
    viewBox="0 0 44.605 44.605"
  >
    <path
      id="linkedin"
      d="M22.3,0a22.3,22.3,0,1,0,22.3,22.3,22.74,22.74,0,0,0-1.085-6.89A22.227,22.227,0,0,0,22.3,0ZM15.822,33.715H10.39V17.374h5.432ZM13.106,15.142h-.035A2.831,2.831,0,1,1,13.142,9.5a2.832,2.832,0,1,1-.036,5.646Zm22.3,18.573H29.976V24.973c0-2.2-.786-3.7-2.752-3.7a2.973,2.973,0,0,0-2.787,1.986,3.72,3.72,0,0,0-.179,1.326v9.126H18.828s.071-14.808,0-16.341h5.431v2.314a5.392,5.392,0,0,1,4.9-2.7c3.574,0,6.253,2.336,6.253,7.355Zm0,0"
    />
  </svg>
  <svg
    v-else-if="name === 'youtube-icon'"
    xmlns="http://www.w3.org/2000/svg"
    width="44.461"
    height="44.461"
    viewBox="0 0 44.461 44.461"
  >
    <path
      id="Tracciato_61"
      data-name="Tracciato 61"
      d="M224.113,216.369l7.231-4.165-7.231-4.165Zm0,0"
      transform="translate(-204.651 -189.973)"
    />
    <path
      id="Tracciato_62"
      data-name="Tracciato 62"
      d="M22.231,0A22.231,22.231,0,1,0,44.461,22.231,22.233,22.233,0,0,0,22.231,0ZM36.121,22.253a36.691,36.691,0,0,1-.572,6.683A3.481,3.481,0,0,1,33.1,31.384c-2.174.572-10.87.572-10.87.572s-8.673,0-10.87-.595a3.481,3.481,0,0,1-2.449-2.449,36.53,36.53,0,0,1-.572-6.682,36.667,36.667,0,0,1,.572-6.682,3.552,3.552,0,0,1,2.449-2.472c2.174-.572,10.87-.572,10.87-.572s8.7,0,10.87.595a3.481,3.481,0,0,1,2.449,2.449,34.819,34.819,0,0,1,.572,6.7Zm0,0"
    />
  </svg>
  <svg
    v-else-if="name === 'golinucci-logo'"
    xmlns="http://www.w3.org/2000/svg"
    width="311.58"
    height="78.274"
    viewBox="0 0 311.58 78.274"
  >
    <g
      id="Logo_OK"
      data-name="QB Golinucci Logo"
      transform="translate(-191.162 -346.412)"
    >
      <g
        id="Raggruppa_41"
        data-name="Raggruppa 41"
        transform="translate(223.166 346.482)"
      >
        <g id="Raggruppa_38" data-name="Raggruppa 38" transform="translate(0 17.9)">
          <g id="Raggruppa_36" data-name="Raggruppa 36" transform="translate(63.852)">
            <path
              id="Tracciato_83"
              data-name="Tracciato 83"
              d="M665.736,505.383c0-9.2,7.1-15.735,16.814-15.735s16.757,6.532,16.757,15.735-7.044,15.735-16.757,15.735S665.736,514.585,665.736,505.383Zm24.6,0c0-5.283-3.351-8.464-7.782-8.464s-7.839,3.181-7.839,8.464,3.408,8.464,7.839,8.464S690.332,510.665,690.332,505.383Z"
              transform="translate(-665.736 -478.687)"
              fill="#822622"
            />
            <path
              id="Tracciato_84"
              data-name="Tracciato 84"
              d="M854.192,467.245V435.38h8.861v31.354c0,2.613,1.363,4.033,3.806,4.033a5.8,5.8,0,0,0,2.5-.568l.4,6.873a14.433,14.433,0,0,1-4.6.738C858.282,477.81,854.192,474.061,854.192,467.245Z"
              transform="translate(-816.127 -435.38)"
              fill="#822622"
            />
            <path
              id="Tracciato_85"
              data-name="Tracciato 85"
              d="M953.9,489.38h8.861v31.069H953.9Z"
              transform="translate(-895.699 -478.473)"
              fill="#822622"
            />
            <path
              id="Tracciato_86"
              data-name="Tracciato 86"
              d="M1051.6,502.953v17.5h-8.861V504.316c0-4.942-2.329-7.214-5.112-7.214-4.541,0-6.191,2.613-6.191,8.236v15.11H1022.6V489.38h7.857v4.087a11.979,11.979,0,0,1,9.386-4.033C1046.537,489.434,1051.6,493.638,1051.6,502.953Z"
              transform="translate(-950.518 -478.473)"
              fill="#822622"
            />
            <path
              id="Tracciato_87"
              data-name="Tracciato 87"
              d="M1356.2,505.383c0-9.2,7.1-15.735,17.041-15.735,6.419,0,11.474,2.783,13.69,7.782l-6.873,3.692a7.62,7.62,0,0,0-6.873-4.2c-4.488,0-8.009,3.124-8.009,8.464s3.522,8.464,8.009,8.464a7.518,7.518,0,0,0,6.873-4.2l6.873,3.749c-2.215,4.885-7.271,7.726-13.69,7.726C1363.3,521.117,1356.2,514.585,1356.2,505.383Z"
              transform="translate(-1216.737 -478.687)"
              fill="#822622"
            />
            <path
              id="Tracciato_88"
              data-name="Tracciato 88"
              d="M1518.439,505.383c0-9.2,7.1-15.735,17.041-15.735,6.419,0,11.474,2.783,13.69,7.782l-6.873,3.692a7.62,7.62,0,0,0-6.873-4.2c-4.488,0-8.01,3.124-8.01,8.464s3.522,8.464,8.01,8.464a7.518,7.518,0,0,0,6.873-4.2l6.873,3.749c-2.215,4.885-7.271,7.726-13.69,7.726C1525.539,521.117,1518.439,514.585,1518.439,505.383Z"
              transform="translate(-1346.207 -478.687)"
              fill="#822622"
            />
            <path
              id="Tracciato_89"
              data-name="Tracciato 89"
              d="M1689.893,489.38h8.861v31.069h-8.861Z"
              transform="translate(-1483.03 -478.473)"
              fill="#822622"
            />
            <path
              id="Tracciato_90"
              data-name="Tracciato 90"
              d="M1189.76,506.876v-17.5h8.861v16.132c0,4.942,2.33,7.214,5.112,7.214,4.541,0,6.191-2.613,6.191-8.236V489.38h8.837v31.069H1210.9v-4.087a11.979,11.979,0,0,1-9.386,4.033C1194.822,520.395,1189.76,516.191,1189.76,506.876Z"
              transform="translate(-1083.916 -478.473)"
              fill="#822622"
            />
          </g>
          <g id="Raggruppa_37" data-name="Raggruppa 37" transform="translate(0 50.095)">
            <path
              id="Tracciato_91"
              data-name="Tracciato 91"
              d="M350.52,692.784a3.734,3.734,0,0,1-.893-2.443l-.016-.466.016-.452a3.645,3.645,0,0,1,.886-2.414,3.057,3.057,0,0,1,2.4-.932,3.1,3.1,0,0,1,2.373.932v-3.135a.308.308,0,0,1,.108-.247.39.39,0,0,1,.262-.092h1.309a.384.384,0,0,1,.27.092.319.319,0,0,1,.1.247v9.347a.325.325,0,0,1-.1.24.367.367,0,0,1-.27.1h-1.217a.372.372,0,0,1-.262-.1.312.312,0,0,1-.108-.24V692.7a3.1,3.1,0,0,1-2.465,1A3.058,3.058,0,0,1,350.52,692.784Zm4.283-1.115a2.168,2.168,0,0,0,.478-1.285q.015-.169.015-.55t-.015-.536a1.863,1.863,0,0,0-.485-1.207,1.687,1.687,0,0,0-1.317-.5q-1.664,0-1.772,1.878l-.015.423.015.424q.108,1.878,1.772,1.878A1.62,1.62,0,0,0,354.8,691.669Z"
              transform="translate(-349.611 -683.508)"
              fill="#822622"
            />
            <path
              id="Tracciato_92"
              data-name="Tracciato 92"
              d="M396.788,703.453a2.571,2.571,0,0,1-1.032-.784,1.749,1.749,0,0,1-.377-1.087,1.816,1.816,0,0,1,.847-1.553,5.366,5.366,0,0,1,2.327-.8l2.111-.282v-.3a1.2,1.2,0,0,0-.339-.932,1.592,1.592,0,0,0-1.094-.311,1.684,1.684,0,0,0-.824.177,2.688,2.688,0,0,0-.5.346q-.185.184-.247.24a.229.229,0,0,1-.231.17h-1.186a.358.358,0,0,1-.239-.085.281.281,0,0,1-.1-.226,1.463,1.463,0,0,1,.377-.8,2.833,2.833,0,0,1,1.117-.776,4.676,4.676,0,0,1,1.849-.325,3.9,3.9,0,0,1,2.65.749,2.514,2.514,0,0,1,.832,1.962v4.434a.325.325,0,0,1-.1.24.367.367,0,0,1-.27.1h-1.248a.373.373,0,0,1-.262-.1.313.313,0,0,1-.108-.24v-.551a2.473,2.473,0,0,1-.963.741,3.676,3.676,0,0,1-1.549.289A3.524,3.524,0,0,1,396.788,703.453Zm3.351-1.56a1.941,1.941,0,0,0,.539-1.482v-.3l-1.541.226a3.563,3.563,0,0,0-1.348.41.813.813,0,0,0-.454.692.788.788,0,0,0,.416.706,1.882,1.882,0,0,0,1,.254A1.941,1.941,0,0,0,400.139,701.893Z"
              transform="translate(-386.134 -693.548)"
              fill="#822622"
            />
            <path
              id="Tracciato_93"
              data-name="Tracciato 93"
              d="M441.711,693.462a.313.313,0,0,1-.108-.24v-9.347a.308.308,0,0,1,.108-.247.39.39,0,0,1,.262-.092h1.279a.384.384,0,0,1,.27.092.319.319,0,0,1,.1.247v9.347a.324.324,0,0,1-.1.24.367.367,0,0,1-.27.1h-1.279A.373.373,0,0,1,441.711,693.462Z"
              transform="translate(-423.022 -683.508)"
              fill="#822622"
            />
            <path
              id="Tracciato_94"
              data-name="Tracciato 94"
              d="M479.4,694.02a.313.313,0,0,1-.108-.24v-7.314l-2.342,1.652a.345.345,0,0,1-.215.07.378.378,0,0,1-.308-.155l-.647-.763a.379.379,0,0,1-.077-.212.331.331,0,0,1,.169-.282l3.451-2.443a.656.656,0,0,1,.385-.1h1.356a.384.384,0,0,1,.27.092.32.32,0,0,1,.1.247v9.206a.324.324,0,0,1-.1.24.367.367,0,0,1-.27.1h-1.4A.373.373,0,0,1,479.4,694.02Z"
              transform="translate(-450.231 -684.066)"
              fill="#822622"
            />
            <path
              id="Tracciato_95"
              data-name="Tracciato 95"
              d="M514.1,693.469a.3.3,0,0,1-.092-.219.3.3,0,0,1,.062-.183l2.265-2.866a2.507,2.507,0,0,1-.632.056,4.294,4.294,0,0,1-1.88-.466,3.42,3.42,0,0,1-1.333-1.186,2.95,2.95,0,0,1-.485-1.638,3.161,3.161,0,0,1,.478-1.674,3.484,3.484,0,0,1,1.418-1.271,4.866,4.866,0,0,1,2.265-.487,5.222,5.222,0,0,1,2.28.459,3.374,3.374,0,0,1,1.44,1.228,3.1,3.1,0,0,1,.485,1.687,2.9,2.9,0,0,1-.2,1.073,4.5,4.5,0,0,1-.455.882q-.254.374-.716.967l-2.712,3.445a.828.828,0,0,1-.208.205.56.56,0,0,1-.316.078h-1.433A.314.314,0,0,1,514.1,693.469Zm3.505-5.2a1.621,1.621,0,0,0,.578-1.306,1.642,1.642,0,0,0-.578-1.313,2.3,2.3,0,0,0-2.85,0,1.781,1.781,0,0,0-.008,2.619,2.34,2.34,0,0,0,2.858,0Z"
              transform="translate(-479.206 -683.508)"
              fill="#822622"
            />
            <path
              id="Tracciato_96"
              data-name="Tracciato 96"
              d="M561.446,693.879a3.36,3.36,0,0,1-1.4-1.045,2.468,2.468,0,0,1-.516-1.4v-.028a.221.221,0,0,1,.093-.184.37.37,0,0,1,.231-.071h1.433a.442.442,0,0,1,.462.283,1.648,1.648,0,0,0,.716.918,2.271,2.271,0,0,0,1.179.3,2.179,2.179,0,0,0,1.441-.48,1.648,1.648,0,0,0,.578-1.341,1.541,1.541,0,0,0-.578-1.243,2.18,2.18,0,0,0-1.441-.48,2.122,2.122,0,0,0-.755.113,2.593,2.593,0,0,0-.57.31,2.592,2.592,0,0,1-.285.177.534.534,0,0,1-.239.049h-1.417a.341.341,0,0,1-.239-.092.287.287,0,0,1-.1-.219l.539-4.829a.408.408,0,0,1,.131-.276.427.427,0,0,1,.3-.106H566.8a.376.376,0,0,1,.262.1.314.314,0,0,1,.108.24v.946a.314.314,0,0,1-.108.24.375.375,0,0,1-.262.1h-4.453l-.247,2.3a3.724,3.724,0,0,1,2.018-.48,4.44,4.44,0,0,1,1.856.388,3.282,3.282,0,0,1,1.364,1.116,2.87,2.87,0,0,1,.508,1.687,3.121,3.121,0,0,1-.524,1.8,3.365,3.365,0,0,1-1.471,1.186,5.458,5.458,0,0,1-2.211.417A5.523,5.523,0,0,1,561.446,693.879Z"
              transform="translate(-517.128 -684.066)"
              fill="#822622"
            />
            <path
              id="Tracciato_97"
              data-name="Tracciato 97"
              d="M607.387,693.35a.313.313,0,0,1-.108-.24v-.72a.814.814,0,0,1,.385-.664l2.434-2.217a18.148,18.148,0,0,0,2.211-1.786,1.855,1.855,0,0,0,.624-1.264,1.387,1.387,0,0,0-.393-1.045,1.63,1.63,0,0,0-1.179-.382,1.714,1.714,0,0,0-1.217.417,1.827,1.827,0,0,0-.555,1.08.4.4,0,0,1-.169.247.511.511,0,0,1-.277.078h-1.371a.329.329,0,0,1-.231-.085.261.261,0,0,1-.092-.2,3.077,3.077,0,0,1,.493-1.56,3.318,3.318,0,0,1,1.34-1.172,4.515,4.515,0,0,1,2.065-.445,5.035,5.035,0,0,1,2.088.388,2.887,2.887,0,0,1,1.286,1.066,2.805,2.805,0,0,1,.431,1.539,2.76,2.76,0,0,1-.578,1.709,8.693,8.693,0,0,1-1.764,1.638l-2.188,2.033h4.391a.385.385,0,0,1,.27.092.319.319,0,0,1,.1.247v1a.325.325,0,0,1-.1.24.367.367,0,0,1-.27.1h-7.365A.373.373,0,0,1,607.387,693.35Z"
              transform="translate(-555.234 -683.396)"
              fill="#822622"
            />
          </g>
        </g>
        <g id="Raggruppa_39" data-name="Raggruppa 39" transform="translate(0)">
          <path
            id="Tracciato_98"
            data-name="Tracciato 98"
            d="M381.718,357.026a19.875,19.875,0,0,1,16.329,8.527l8.377-5.939a30.171,30.171,0,0,0-54.152,10.747,48.847,48.847,0,0,0,9.8,3.377A19.9,19.9,0,0,1,381.718,357.026Z"
            transform="translate(-351.734 -346.761)"
            fill="#822622"
          />
          <path
            id="Tracciato_99"
            data-name="Tracciato 99"
            d="M409.76,489.67H379.595v10.265h17.77A19.906,19.906,0,0,1,361,498.068a53.307,53.307,0,0,1-11.389-3.791,30.165,30.165,0,0,0,60.149-3.307h0Z"
            transform="translate(-349.611 -460.805)"
            fill="#7a7a7a"
          />
        </g>
        <g id="Raggruppa_40" data-name="Raggruppa 40" transform="translate(63.852 67.64)">
          <path
            id="Tracciato_100"
            data-name="Tracciato 100"
            d="M673.727,697.364v7.044H671.7V703.6a2.879,2.879,0,0,1-2.291.916,3.627,3.627,0,1,1,0-7.253,2.878,2.878,0,0,1,2.2.851v-.746Zm-2.086,3.522a1.876,1.876,0,1,0-1.868,1.951A1.818,1.818,0,0,0,671.641,700.885Z"
            transform="translate(-665.736 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_101"
            data-name="Tracciato 101"
            d="M711.509,703.753l.709-1.466a5.179,5.179,0,0,0,2.55.681c.982,0,1.35-.249,1.35-.642,0-1.152-4.432.026-4.432-2.789,0-1.335,1.255-2.278,3.4-2.278a6.238,6.238,0,0,1,2.823.615l-.709,1.453a4.352,4.352,0,0,0-2.114-.524c-.955,0-1.364.288-1.364.655,0,1.2,4.432.039,4.432,2.815,0,1.309-1.268,2.239-3.464,2.239A6.5,6.5,0,0,1,711.509,703.753Z"
            transform="translate(-702.264 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_102"
            data-name="Tracciato 102"
            d="M747.357,703.753l.709-1.466a5.177,5.177,0,0,0,2.55.681c.982,0,1.35-.249,1.35-.642,0-1.152-4.432.026-4.432-2.789,0-1.335,1.255-2.278,3.4-2.278a6.238,6.238,0,0,1,2.823.615l-.709,1.453a4.352,4.352,0,0,0-2.114-.524c-.955,0-1.364.288-1.364.655,0,1.2,4.432.039,4.432,2.815,0,1.309-1.268,2.239-3.464,2.239A6.5,6.5,0,0,1,747.357,703.753Z"
            transform="translate(-730.871 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_103"
            data-name="Tracciato 103"
            d="M785.433,682.777a1.2,1.2,0,0,1,1.323-1.139,1.177,1.177,0,0,1,1.323,1.1,1.335,1.335,0,0,1-2.646.039Zm.259,2.121h2.127v7.044h-2.127Z"
            transform="translate(-761.256 -681.638)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_104"
            data-name="Tracciato 104"
            d="M804.336,700.885c0-2.121,1.7-3.627,4.091-3.627a3.394,3.394,0,0,1,3.286,1.794l-1.65.851a1.928,1.928,0,1,0-1.65,2.933,1.816,1.816,0,0,0,1.65-.969l1.65.864a3.429,3.429,0,0,1-3.286,1.78C806.041,704.512,804.336,703.007,804.336,700.885Z"
            transform="translate(-776.341 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_105"
            data-name="Tracciato 105"
            d="M854.165,697.778v7.044h-2.018v-.838a3.026,3.026,0,0,1-2.277.943,2.864,2.864,0,0,1-3.136-3.168v-3.98h2.127v3.679c0,1.178.545,1.7,1.486,1.7.982,0,1.691-.6,1.691-1.9v-3.483Z"
            transform="translate(-810.175 -694.518)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_106"
            data-name="Tracciato 106"
            d="M897.871,697.259v1.885c-.177-.013-.314-.026-.477-.026a1.765,1.765,0,0,0-1.95,1.964v3.325h-2.127v-7.044h2.032v.93A3.016,3.016,0,0,1,897.871,697.259Z"
            transform="translate(-847.349 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_107"
            data-name="Tracciato 107"
            d="M920.861,682.777a1.2,1.2,0,0,1,1.323-1.139,1.177,1.177,0,0,1,1.323,1.1,1.334,1.334,0,0,1-2.645.039Zm.259,2.121h2.127v7.044H921.12Z"
            transform="translate(-869.33 -681.638)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_108"
            data-name="Tracciato 108"
            d="M947.755,697.364v7.044h-2.032V703.6a2.878,2.878,0,0,1-2.291.916,3.627,3.627,0,1,1,0-7.253,2.878,2.878,0,0,1,2.2.851v-.746Zm-2.086,3.522a1.877,1.877,0,1,0-1.868,1.951A1.818,1.818,0,0,0,945.669,700.885Z"
            transform="translate(-884.415 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_109"
            data-name="Tracciato 109"
            d="M1001.442,700.375v4.033h-2.127v-3.718c0-1.139-.532-1.663-1.391-1.663-.955,0-1.623.589-1.623,1.846v3.535h-2.127v-3.718c0-1.139-.5-1.663-1.391-1.663-.941,0-1.609.589-1.609,1.846v3.535h-2.127v-7.044h2.032v.812a3.032,3.032,0,0,1,2.3-.917,2.776,2.776,0,0,1,2.414,1.152,3.356,3.356,0,0,1,2.645-1.152A2.781,2.781,0,0,1,1001.442,700.375Z"
            transform="translate(-923.743 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_110"
            data-name="Tracciato 110"
            d="M1057.571,700.885c0-2.121,1.7-3.627,4.036-3.627s4.023,1.506,4.023,3.627-1.691,3.627-4.023,3.627S1057.571,703.007,1057.571,700.885Zm5.9,0a1.876,1.876,0,1,0-1.868,1.951A1.81,1.81,0,0,0,1063.476,700.885Z"
            transform="translate(-978.427 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_111"
            data-name="Tracciato 111"
            d="M1123.6,691.939v-7.384h2.127v7.266a.831.831,0,0,0,.913.93,1.437,1.437,0,0,0,.6-.131l.1,1.584a3.593,3.593,0,0,1-1.1.17A2.31,2.31,0,0,1,1123.6,691.939Z"
            transform="translate(-1031.117 -683.966)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_112"
            data-name="Tracciato 112"
            d="M1151.91,697.364v7.044h-2.032V703.6a2.879,2.879,0,0,1-2.291.916,3.627,3.627,0,1,1,0-7.253,2.878,2.878,0,0,1,2.2.851v-.746Zm-2.086,3.522a1.876,1.876,0,1,0-1.868,1.951A1.818,1.818,0,0,0,1149.823,700.885Z"
            transform="translate(-1047.334 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_113"
            data-name="Tracciato 113"
            d="M1215.278,697.778l-3.1,7.044h-2.2l-3.082-7.044h2.2l2.032,4.792,2.1-4.792Z"
            transform="translate(-1097.598 -694.518)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_114"
            data-name="Tracciato 114"
            d="M1248.965,700.885c0-2.121,1.7-3.627,4.036-3.627s4.023,1.506,4.023,3.627-1.691,3.627-4.023,3.627S1248.965,703.007,1248.965,700.885Zm5.9,0a1.876,1.876,0,1,0-1.868,1.951A1.81,1.81,0,0,0,1254.87,700.885Z"
            transform="translate(-1131.162 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_115"
            data-name="Tracciato 115"
            d="M1292.375,703.753l.709-1.466a5.179,5.179,0,0,0,2.55.681c.982,0,1.35-.249,1.35-.642,0-1.152-4.432.026-4.432-2.789,0-1.335,1.254-2.278,3.4-2.278a6.238,6.238,0,0,1,2.823.615l-.709,1.453a4.355,4.355,0,0,0-2.114-.524c-.954,0-1.364.288-1.364.655,0,1.2,4.432.039,4.432,2.815,0,1.309-1.268,2.239-3.464,2.239A6.5,6.5,0,0,1,1292.375,703.753Z"
            transform="translate(-1165.804 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_116"
            data-name="Tracciato 116"
            d="M1335.991,698.326a3.121,3.121,0,0,1-1.718.445c-1.745,0-2.741-.851-2.741-2.527v-6.179h2.127v1.715h1.814v1.571h-1.814v2.867a.828.828,0,0,0,.9.93,1.549,1.549,0,0,0,.873-.262Z"
            transform="translate(-1197.052 -688.363)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_117"
            data-name="Tracciato 117"
            d="M1364.1,697.259v1.885c-.177-.013-.314-.026-.477-.026a1.766,1.766,0,0,0-1.95,1.964v3.325h-2.127v-7.044h2.032v.93A3.016,3.016,0,0,1,1364.1,697.259Z"
            transform="translate(-1219.409 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_118"
            data-name="Tracciato 118"
            d="M1393.33,697.364v7.044H1391.3V703.6a2.878,2.878,0,0,1-2.291.916,3.627,3.627,0,1,1,0-7.253,2.878,2.878,0,0,1,2.2.851v-.746Zm-2.086,3.522a1.876,1.876,0,1,0-1.868,1.951A1.818,1.818,0,0,0,1391.244,700.885Z"
            transform="translate(-1239.991 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_119"
            data-name="Tracciato 119"
            d="M1450.217,703.753l.709-1.466a5.179,5.179,0,0,0,2.55.681c.982,0,1.35-.249,1.35-.642,0-1.152-4.432.026-4.432-2.789,0-1.335,1.255-2.278,3.4-2.278a6.239,6.239,0,0,1,2.823.615l-.709,1.453a4.355,4.355,0,0,0-2.114-.524c-.954,0-1.364.288-1.364.655,0,1.2,4.432.039,4.432,2.815,0,1.309-1.268,2.239-3.464,2.239A6.5,6.5,0,0,1,1450.217,703.753Z"
            transform="translate(-1291.765 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_120"
            data-name="Tracciato 120"
            d="M1492.957,702.195l1.132,1.178a3.925,3.925,0,0,1-3.027,1.139c-2.536,0-4.186-1.532-4.186-3.627a3.664,3.664,0,0,1,3.927-3.627,3.528,3.528,0,0,1,3.791,3.561l-5.427,1.008a1.948,1.948,0,0,0,1.95,1.048A2.544,2.544,0,0,0,1492.957,702.195Zm-4-1.519,3.573-.668a1.693,1.693,0,0,0-1.732-1.2A1.761,1.761,0,0,0,1488.961,700.676Z"
            transform="translate(-1321.018 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_121"
            data-name="Tracciato 121"
            d="M1536.73,697.259v1.885c-.177-.013-.314-.026-.477-.026a1.765,1.765,0,0,0-1.95,1.964v3.325h-2.127v-7.044h2.032v.93A3.015,3.015,0,0,1,1536.73,697.259Z"
            transform="translate(-1357.169 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_122"
            data-name="Tracciato 122"
            d="M1564.047,702.195l1.132,1.178a3.926,3.926,0,0,1-3.027,1.139c-2.536,0-4.187-1.532-4.187-3.627a3.665,3.665,0,0,1,3.928-3.627,3.528,3.528,0,0,1,3.791,3.561l-5.427,1.008a1.947,1.947,0,0,0,1.95,1.048A2.543,2.543,0,0,0,1564.047,702.195Zm-4-1.519,3.573-.668a1.693,1.693,0,0,0-1.732-1.2A1.761,1.761,0,0,0,1560.051,700.676Z"
            transform="translate(-1377.749 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_123"
            data-name="Tracciato 123"
            d="M1610.766,700.375v4.033h-2.127v-3.718c0-1.139-.546-1.663-1.486-1.663a1.67,1.67,0,0,0-1.759,1.9v3.483h-2.127v-7.044h2.032v.825a3.282,3.282,0,0,1,2.427-.93A2.816,2.816,0,0,1,1610.766,700.375Z"
            transform="translate(-1413.9 -694.104)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_124"
            data-name="Tracciato 124"
            d="M1648.633,682.777a1.2,1.2,0,0,1,1.323-1.139,1.177,1.177,0,0,1,1.323,1.1,1.334,1.334,0,0,1-2.645.039Zm.259,2.121h2.127v7.044h-2.127Z"
            transform="translate(-1450.104 -681.638)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_125"
            data-name="Tracciato 125"
            d="M1674.493,698.326a3.12,3.12,0,0,1-1.718.445c-1.746,0-2.741-.851-2.741-2.527v-6.179h2.127v1.715h1.814v1.571h-1.814v2.867a.828.828,0,0,0,.9.93,1.55,1.55,0,0,0,.873-.262Z"
            transform="translate(-1467.182 -688.363)"
            fill="#7a7a7a"
          />
          <path
            id="Tracciato_126"
            data-name="Tracciato 126"
            d="M1702.193,686.761V693.8h-2.032v-.812a2.878,2.878,0,0,1-2.291.916,3.627,3.627,0,1,1,0-7.253,2.878,2.878,0,0,1,2.2.851v-.746Zm-4.091-.9-2.468-1.885h2.291l1.841,1.885Zm2,4.425a1.876,1.876,0,1,0-1.868,1.951A1.817,1.817,0,0,0,1700.106,690.282Z"
            transform="translate(-1486.469 -683.501)"
            fill="#7a7a7a"
          />
        </g>
      </g>
      <g
        id="Raggruppa_43"
        data-name="Raggruppa 43"
        transform="translate(191.162 346.412)"
      >
        <rect
          id="Rettangolo_101"
          data-name="Rettangolo 101"
          width="25.991"
          height="78.203"
          rx="12"
          transform="translate(0)"
          fill="#822622"
        />
        <g id="Raggruppa_42" data-name="Raggruppa 42" transform="translate(3.904 8.816)">
          <path
            id="Tracciato_127"
            data-name="Tracciato 127"
            d="M221.5,407.08v3.086h-3.869V407.08a8.436,8.436,0,0,1-7.146-8.428c0-4.938,3.846-8.594,9.092-8.594,5.223,0,9.092,3.632,9.092,8.594A8.438,8.438,0,0,1,221.5,407.08Zm3.276-8.428a5.2,5.2,0,1,0-7,5.056v-3.418h3.561v3.418A4.97,4.97,0,0,0,224.779,398.653Z"
            transform="translate(-210.488 -390.059)"
            fill="#fff"
          />
          <path
            id="Tracciato_128"
            data-name="Tracciato 128"
            d="M230.017,523.862l-1.994-1.852a8.893,8.893,0,0,1-5.555,1.852c-3.656,0-6.338-1.9-6.338-4.558,0-2.089,1.116-3.537,3.656-4.961a4.952,4.952,0,0,1-1.709-3.513c0-2.421,2.041-4.083,5.175-4.083,2.872,0,4.771,1.472,4.771,3.822,0,1.709-1,2.967-3.252,4.2l3.038,2.825a10.675,10.675,0,0,0,.831-2.588l2.967.926a10.961,10.961,0,0,1-1.519,3.774l1.947,1.8Zm-4.178-3.869-4.012-3.751c-1.519.878-2.065,1.638-2.065,2.659,0,1.211,1.139,2.065,2.967,2.065A5.315,5.315,0,0,0,225.839,519.992Zm-4.392-9.211c0,.641.261,1.116,1.282,2.113,1.638-.878,2.16-1.5,2.16-2.255,0-.807-.57-1.377-1.638-1.377C222.112,509.262,221.447,509.9,221.447,510.782Z"
            transform="translate(-214.99 -483.177)"
            fill="#fff"
          />
          <path
            id="Tracciato_129"
            data-name="Tracciato 129"
            d="M233.015,619.753c0,2.873-2.279,4.534-6.647,4.534h-8.594V607.67h8.119c4.154,0,6.291,1.733,6.291,4.32a4,4,0,0,1-2.208,3.656A4.1,4.1,0,0,1,233.015,619.753ZM221.6,610.566v3.917h3.822c1.875,0,2.9-.665,2.9-1.97s-1.021-1.947-2.9-1.947Zm7.549,8.784c0-1.4-1.068-2.065-3.062-2.065H221.6v4.107h4.487C228.078,621.391,229.146,620.774,229.146,619.35Z"
            transform="translate(-216.303 -563.716)"
            fill="#fff"
          />
        </g>
      </g>
    </g>
  </svg>
  <svg
    v-else-if="name === 'golinucci-logo-legacy'"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    width="119.041"
    height="55.191"
    viewBox="0 0 119.041 55.191"
  >
    <image
      id="golinucci70"
      width="119.041"
      height="55.192"
      xlink:href="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQEAYABgAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCAD5AnADASIAAhEBAxEB/8QAHQABAAEFAQEBAAAAAAAAAAAAAAYBBAUHCAMCCf/EAFgQAAEDAwIDBQUDBwcHCgILAAECAwQABQYHERIhMQgTQVFhFCIycYEVkaEjQlJigrHBFjNykrLC0SQlU1V1k6IJNDc4Q3Ojs8PSRPAXJzZUV2OD0+Hi4//EABoBAQADAQEBAAAAAAAAAAAAAAACAwQBBQb/xAA0EQACAgEDAgQDBgcBAQEAAAAAAQIDEQQhMRJBBRNRYSIycRSBkaGxwSMkM0LR4fBSFfH/2gAMAwEAAhEDEQA/AOy6UpQClKUApSlAKUpQClKUA2qnOq1ishyGyY/FMq9XWHBaA33fdCd/kOppk6otvCMpVa0Fl/abxu3vqj49aJV3KeRedX3DZ+W4Kj9QKjCe1RcuL3sQiFPkJigf7NUu+tdzfDwvVTWVA6kqlQbRrUONqPjj90ZgLgOx3yy8ypzjAOwUCFbDfkfKpzVsWmsow2QlXJxlyitKUrpEUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgKVE9Tc8smA4+u6XZ3jdV7seKhQ7x9fkB5eZ8Kgeu+tTWGvfyfxttmdfXE++snibi78gCB8S/1fDlv5VBNLtKMnz7IE5hqe7MVE3C0R5JKXZPkOH8xv05b9BVMrd+mPJ6FOjSh51zxH839Dx/lvrdqi6tOKQXLRbCogOR/yaR83l8yf6O3yr2h9mvKrs77Tk2YR0Oq5qKUrkr+W6in99dOw4seHGbixGG2GGkhDbbaeFKQPADwr3rnkp/M8nX4lOG1MVFfTf8AE5kuPZXWGN7fmKFu/ovweFJ+oWdvur2xDsvtMzEvZVkCZDKTv7NBQU8fzWrp9E/UV0rvSu/Z685wcfiurcenrMZj1jtWPWtu12aAzCiNDZLbSdh8z5n1POsn41TnVelXcHnttvLFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUPIUBSuee0fqxMbm/wAgMMdWu4vrDMyQwd1JKuXco2/OPifDp57V1u129mfkYpgvFIuSl9w7OQOINq6FLQ/OV4b/AHb1kuz9o1/J1aMsytPtF+dBWyys8Qi8X5yvNz18PnWec3N9MfvPUoojp4+fevovX/RkdBtHYmHw/tjI2I87IXlcQWocaYydvhTv+d13V9B67iqtU8etXRiorCPPuundNymytKUqRWKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKHpQFDTceYrgvtIatZVN1evEfG8rvNttlvWILTcG4OsoWpvktZCFAElZUN/ICoBHz7VKQgrj5rmbyQdipu6SVDf6KrNLUxTxg9yvwK2cFNySyfpnuB403HnX5jOakakoWpC8+y1K0nZSTeJAIP8AXrK4blWrGV5RbsdtOd5W5Mnvhpv/ADxI2T5qPv8AwpSCo+gNcWri3jBOXgFkYuTmtj9JapVpaIqoFqiQlSHpKo7CGi86oqW4UpA4lE7kk7bknzrXev8Aq7a9LMfQ6UIm3qZuIMLj2326uL8QgfieQ8SNDkorLPErplbNQhu2bPJ8zTceYrj7HNN9XddLd/KfMszesdnmArhxQ0pSVoPilgKSlKD4KUSpXXmNidaZxYdQOz7nUZq35C82l1PtESVGUpLMlIOykrbVukkct0nfqKpd7W/TsepX4VCyTrVq6/TH7n6G0qC6G5+xqRp5CyNDSWJW5YmspO4afRtxAehBCh6KG9SXK75b8ax2ff7q93MGAwp95W252SOgHiT0A8SRVyaayeVOqcLPLa34MoTy50CgehH31xzGc1f7R10ly7bc14zhrTpaQA6pDagPAhHN5fTfchI9Ku5nZYzfGo6rpheoPeXRscYQhpcJSiOewcS4rn5b7D5VV5re8Y7Ho/8Az6ofDbalL0xn8Wdd0rn/ALNWr18vd7lacahMrj5VACu7dcQEKkBHxJUBy4wOe45KTz8Nz0BVsJqayjDqNPPTz6JlaUpUikUpSgKVprtK6oRsUxt+wWmYk3+eju9m1e9FaPxLPkojknx57+FSTX3NXMH08lT4biUXKSoRoZ5EpWrqvb9VIJ+e1cu6I4Fd9SM2RPnpckWuPJS9c5L6ie958Rb36lSvw33+ea6x56I8s9XQaSDi9Rb8sfzNj9kPTxDy3M7u8bi4FFu2JcTy4vznfp8I/a9K6dq3hRY0GI3EhsNR47SQhtppISlCR4ADpXvV1cFCODHq9TLU2ubK0pSpmYUpSgFKUoClKopQSkkkAAbknwqHt6m4K9k8fG4+RxJFykOd2htndaOLbpxgcO/h168q42lySjCUvlRMqUpXSIqlPGozmGeYjiWwyC+RYjpG6Wdyt0j+gndW3rttXG0uTsYyk8RWSTUrUzHaF01ck9yq4Tmk77d6uGrh/Dc/hWw8ZySxZNAE6w3SNcI/QqZXuUnyUOqT6HauKcXwyydFle8otGXpSlSKhSrM3S2gkG4RARyILyeX41T7Vtn+sYf+/T/jTJ3pfoXtK+G1ocQFoUlaVDcKB3Br7ocFKVZm6W0HY3CICPAvJ/xodxkvKVZfats/1jD/AN+n/GrgvNBnvy6jutuLj4vd2896DDPWlWf2ra/9ZQ/9+n/GrpKgpIKSCDzBHjQYaPqlKUOClWarnbUqKVT4iVA7EF5O4/Gqfats/wBYw/8Afp/xpk70svaV4Pyo7DYcffaaQropawkH614/ats/1jD/AN+n/Ggwy9pVq1cYDrgbanRnFq6JS6kk/SrqhzGBSqEgDc1afals8bjD/wB8n/Gh1JsvKVZ/alr/ANZQ/wDfp/xq869KBpoUpVCQBuTsBQ4KrUCyXV7TzH3lx5uSRnX0clNRQXlA+RKNwD8zWCi9oXTR57u13CcwP03IiuH8NzUHZFdy+OluksqLx9DbNKwGLZniuUI3sN9gz1bblttzZwDzKDsofUVn6mnkplFxeGVpShO1DgqlQvKtU8Cxp5ce55HF9pRyUwwS8sHyIRvwn57VGGe0Ppq493aps9sfpriK4fw51B2RXLL46a6SyoNr6G26b1GsUzvD8oIRYshgzHT0ZC+F358CtlfhUiecbabU464ltCeZUo7AVJNPgqlGUXho9KVZfats/wBYw/8Afp/xqqLlblrCET4qlKOwAeSSfxruTnSy8pSlDhQ1H9RbheLXhN2mY/b3rhdkRlCFHaTxFTquST8gSCfQGpAaUa2OxeJJmk+y9pEzhOMov2QwkuZXcvy0hx8BbkVJ5hsE9Fc91HqSdj0Fbr2T+iKqKeFRjFRWEWX3zvm5z5ZE9WM0t2n+C3HJp4Qv2dHDHZJ2L7yuSED5nr5AE+FaW7HWIXC6Sbrq/lJU/dby44iEpY6N8X5RwDw3ICU+SUnwNRHWy6zdb9fLZpnYn1fYlqfUmU8g+6VJ/n3fL3QOBO/5xP6VdcWW3Q7RaYlrt7CY8OGylhhpHRCEgBIH0FVR+OeeyPQs/lNMof3T3fsuy+8tcuv1txfGrhkF3e7mFAYU86rx2HQDzJOwA8SRXD2nNvunaB7QC7rkKVqtyFe1TGwfcZjIP5OOk+ROyfAndauu9bI7eubrbj2rAYb2weHt9wAPVIJDSD9QpW36qam3Ymw1OP6U/bz7IRNv73tBJHMMIJS0n5fEr9uoT/iWdPZGnTx+x6KWofzS2RvVltDLKGmkJQhCQlKUjYJA6ACubu3/AAWXNOrBdCkd8xd+4QdufC4y4pXP5tJ+6ula5y7fjqE6VWVgn313xtaR6Bh4H+0Ktux5bMHhjf2uDXqRv/k97i4WMvtCye7QuLJbHgCoOJV/ZR91bA7bjstvQqUiPv3Tk+OmT/Q4uIf8YRWu/wDk9oSt8xuKgQk+yMIPgSO9Kv3p++uldQ8Wt+a4ZdMYue4jz2C2VgbltW+6Fj1SoJUPlVdScqcGvX2Rq8Sc3wmv0RidC41ui6O4k1agn2U2phYKR8SlIClk+pUVE+pNTWuNsP1Czvs7TFYTm9geumPJdUqDJaUU7JJJJZWfdUknmUHYpJPTpUsyLtfY4LcoY3i93kXBaSECd3bTSVeB9xSlKHpy38xUo3RSw9iq7w2+djlBdSfDLbWZpiJ2zcCfteyJz7ccy+76kFx1G6tv/wAvcfICuphvttXNfZv09y29Z5J1j1HQ41cpCVfZ8V1BQtHEOHj4T8CQj3EpPPYknwJ6VNdqzu/Uq8QcU4Vp56Vhv3FKUq488pXw84hlpTrq0obQkqUpR2CQOpNfe9aa7U+eMY5g71ghyU/at1T3RQlXvNsn41Hy3Hu/U1GclCOWW6emV1ihHuaJ1YzK7auajRrPaUkwRJ9ltjO+wVxK4e8V6nr6D5V1fpVhcPA8OjWGK6X3AS5JeI27x1W2528ByAA9K0b2P8AjyVuZ7cElSo7qmICPAK4dluH6K2H1rp6qKIv55cs9LxO6Mcaar5Y/qVpSlaTyBSlKAUpSgKUpUY1SvzON6f3u7OykxltQ3Ex1k8y8pJCAPXi2rjeNzsIuclFHOfag1Wl3S8yMPsExTVsiktzXGl7e0Oj4kbj81PTbxO9Rbsv4q9kmqUKYpKvY7RtNfX+sk/k0/Mq2+iVVq48bz3LiWtavmSa7j7O+DfyJwBhMprgulw2kzNxzTuPdR+yPxJrz6s229TPq9Z5eg0nlw5lt/k2XVBQ1Bdcc2TguAyro0pPt7/8Ak8JJ8XVA+9+yN1fSt7aSyz5auuVklGPLIjrFqXd1ZC3p3p2j2rIpB4JElHNMQeI36BQHMk8k/PpdYFoXjlrH2llW+SXt094+9KUVNBfok/F81b7149mDCTZsWOW3YKdvd8/Lqcc5rQyo7pG/mr4j8x5VuSq4R6vika7rvJ/hVPbu/Ui9208we6QlQ5eK2juiNt24qG1D5KSAR9K5o1Jxi/aF5tEyLE5r/wBlSl7N8Z3HLmWXB+cNuh/iK6/8ahGueON5RpdereWwp9qOqVG5bkONjiG3z2Kf2qW15WVyNFq5VzUZ7xfKMppvlcHNcQhZBB90Pp2da33LTg5KQfkfw2qQrSFoUg77KG3KuX+xVkLjd1vOLuuEtutCYynyUkhK/vCkfdXUVSqn1xTK9bR9nvcFwc2656MYZjen11yS2faDc5lbagp2QVpUVOJSQQR+tUY7NWlWOZ3YLpdchTMV3EpLDHcvFsAhIUr5/EmtudriX7Po5KY4tjJmMN/PZXH/AHK8Ox/E9n0jD+3/ADq4POfcEo/uVS4R87GOx6MdRatA5dW/Vg21Z7fGtVqiW2GgojRWUstJJ32SkAD91XZpvStR4h8nmNt65s1x0WwvF9ObpkNq+0G5sZTakl2TxpVxOJSQQR+t+FdKVp/tdyjH0fdbB/5xOZbP4q/u1Vck4Ns2aCycb4qLxlo1N2atLMazuwXS45CmYpUeUllkMvlsbcIUT+Irp244vap2FqxJ1DqbYYqYnChey+7SAAOL5CtadjyIGdKFSdvekT3SfkkJT/Ctzmo0RSgizxG+c9TJZ2T2OUu0LopZcPxNOS4y7KS1HdS3KZfc4+SjslST/S2G3rWyOyjm/wDKXBPsOY7xXGzbNHiPvLYPwK+nNP0HnV52sH+DSCRET8cuYw0keZ4+P+7XP2NP3HRXWiO3OWsxdkIkK22DsZwA8X06/NNVS/h2ZXBvqT1mjcZv40219x23Q15sOtvMoeaUFtrSFJUOhB6GvSth4Bz1rLonhdpwe/5LB+0EXFlBkBS5JUkqKhvuNvU1idCdFcSyrTuHf783OXKkuuFJakFCeBKuEDb6Gtr9o97udFsiO+xWyhA+riBV5oPCMDSDGo5G3FCS7t/3hK/71UdEfM47HprVXLS/N3/Yus80/wAdzS0QrTeW5PssJQUyhh4t7bJ4Rv8ASuU+0ngdiwLJbZCsJkpYlRC6tLzvGQoLI5H5V2zXIvbAf9t1VtkAcy1Cbb2/pLUf4io6mK6M9yzwi2fnqOdt9jbOkOjeI2eJj+VIamruyYrcgqW/7gWtvmeHb9atw1a2mN7FaokQf9gwhsfspA/hV3V8YqKwjzbrZWzcpPJ4y2ESYrsd3fgdQpCtjsdiNq5o150aw7E9PZV+s3tzctl5sDvpHGlQUrYjbb1rpz51p3teSAzpIpnfm/PZTt8t1fwqFqTi8l+gsnG+Ki8ZZHNJ9CsLvGAWO93lme5OmR0yHOGSUpIUd0+7t+iRXQgAAAHQdKxWGwfsvEbPbdtvZYLLJ/ZQB/CssalCKitirUXztm3J5MXlN+teM2OTerzKRGhx08S1K6nySB4k9AK57RPz/Xq5vs2993HcLaXwLWOr3odvjV6fCP32Ool0n60axRsHs8lSLBbnld86jmk8PJx71/RT8x+lXS+P2iBYrPGtFrjJjQ4rYQ02nwH8T61X/Ufsa8R0cE2sze/0X+SCYrohp5YWEBVlTc5A+J+ce8JPj7vwj7qy940s0+uscsScTtiBtsFR2Qyoeu6NqmdVqzojjGDG9Ta31OTz9TmGJpUjBe0NiiLZIdftcxbsiOFn32y0j30k+O3Enn6+m9dPCvByOw4+1IcYbW8zv3bikAqRv12PhvXvvSFahnB3Uaid/S5cpYLG9XKDZ7XIudzlNxYcZBcddcOwSkf/AD0rneZk2da4X2TZ8QW9YsUYVwyZiiUqcT+sRzJP6APTqat9cshuWpWpsPS/G3iIMeRwzHE/CpwfGVfqtjf9rf0roTDccteKY5EsVnYDUWMjb9ZxX5y1HxUT1qvLslhcI1KMdJWpyWZvj2Xr9SDYfoRp/YY6BJtpvEobFT8xXECfRA90fjUiuemGn9wjdxIxG0hHgWY4aV/WRsamFKsUIrbBklqLpPqcnk5cyvSKLhOsOGS7K685abhdW0904d1MrQoKI38Ukb7fI10Xl+P2/Kcek2K6d97HKCQ53ThQrkoK6/Ssk9HYeW0t5htxTKuNsrQCUK223HkdiRv617ct6RrjHOO5O7VWW9Lk913ON+0zptjmAfYa8eMpInd+HUPu958HBsR/WNbP0N0cxFeL41l8pua5dVNomgl/Zvi34k+7t022qH9tuZx5RjsHfkzDceP7a9v/AE66M09h/Z2B2GD0LFuYQfo2mqIQi7XtwelqdRatFX8W7yZ6lKVqPEFKUoCmwFah7U2pidPdPnWoD4RfrsFR4AB95obe+9+yCNv1in1rat0nRLZbZNxnPojxYrSnnnVnZKEJG6lH0AFcMRVz+0Z2jEKfDzdjaVxcB/8Ah4DR6eilkj5Kc8hVN02lhcs9Hw3TRsm7bPkju/8ABuzsUaenHcIczG5NEXO/AKa4x7zcUH3f653X8uDyroQ8tzXnHZajx22GG0ttNpCEISNgkDkAKtMinC2Y/cLiSB7LFce3J5e6kn+FThFQjgzai6Wpuc33Pzp16vj2Za3ZDLY3c7y4GFFSDvulvZpG39Lh3/ar9E8XtTFixu2WWMAGYEVuMgD9FCQkfur83NGYRvOsGKxXt3O9vEdbu/PiSHApW/0Br9NR0rPpvi6pHs+O4rjVSuEh4VyL/wAoJekrm4rjyCOJtt+Y6N/0ilCP7LlddV+ePaIvErUHtA3KLagZJ9rbtEBsfnFB7vYfNwrP1qepeIY9TN4HV1anrfEVk6V7DlhVa9Gjc3G+Fd3nuyEk9S2nZofihR+tb6rC4PYI2LYfacdiEFm3RG44UBtxlKQCo+pO5+tZk1bCPTFI87VW+ddKfqy2uMGFcYq4lwhx5cdY2W0+2FoV8weRrEWXCMNssz2yz4nYrdJ/00W3tNL/AKyUg1IBValhFSnJLCYpSldIilKUBjMmvduxyxyrzdpAYhxUcbizzPoAPEk8gK4D1GyNzMM6ul/KVpE2QVNNqO5Q2PdQPokJFdMdsq/RYmBw7B3o9qnyku92DzDbfMq+XEUitAaA2hm9auWCJJaDrCZHfOJPQ8CSsfikVh1EnKagfSeEVKmiWpl7nZOkGPqxjTWx2d1HA+1FSt9JHMOL99YPyKiPpUtqlBW1LCwfOzm5ycn3K0pSukRSlKAUpSgFcu9tbIUu3CzYyy/v3CFSpDaVdFK91G/0CvvrpyZIaiRHpTyglpltTi1HwSBua/O7OchmZVllxv00nvZjylhO/wACfzUj5J2H0rLqp4hj1PZ8E0/mX9b4ibH7JWNM3zU326Wwl6Pao6pHCtO6e8J4Ubj6qUPVNdn1z92KrP7Pid4vS29lTJSWUK80tp3/ALSzXQVT08cVop8Xu8zVS9thXLHaGnOZtrrYsGZXvFiONMrSDyLjhCnDy8kcI9NjXUyiAkn0rkDRd/8AlJ2n37pITxbyZcn5bBQT+8UvfEfVnPDY9Lnb/wCU/wATruOy3HjtsNJCW20BCUjwA5CvWlKvPNFfDyA4ytCuYUkg191RR90/KgRxf2bgq19oKNAQdk8UqMr1CW1n96RXaFcbaANGX2kxIRzS3ImvH5FDg/vCuyqz6b5T1fGP60fojQHbYmd3hFkgb7F64F0+oQ2of36nPZsiex6MWFBH84hx3+u4pX8a1N23pgVccYt4PwNvvEf0lIA/smt66SRDB0xxuIRsW7ayD/UBpHe5i74dBWvVtkqpSlaDyh41z/22Jim8NskLfk/OUsj+ig/+6ugBXL/bemE3HG7fvyDTz23zKR/Cqb3itm/wuPVqoG2OzTETE0YsWw2L6HHlftOK/gBWyDUW0nhiBpljcYDbhtrKj81ICj+JqU1OCxFIy6iXVbKXq2ab7S6TcH8Hx1J5z782rbzCBsf/ADKx/a4wj7bxBrKYTW86zjZ3hHNccnn/AFT73yKqyOpP+c+0Vp/aD8ENh+cfQ7Hb8WhW3JkdiZEeiSW0uMvILbiFDkpJGxFQcVPqRqjc9P5Ul23/ADNO9k/N/wCUWDGwTXeK42bZocR5rYPwH6c0/RPnW6a4tiLl6J69FpwrFuD3Co+DsRw8j9P3oNdmx3UPsNvNLSttxIUhSTyIPQ0pk2sPlEvEqYws8yHyy3RqntZyTH0elJB/npbDfz97f+FbGxOF9nYtabeRt7NBZZ/qoA/hWsO1N/lVkxiy9ftK+Ms7efUf3q3EnoB6VJfOzPN4ogvd/sfXjXIGsiE33tRxLeOYMyHFPp8O/wC8119051yLZEi+9sNSx7yUXZ1zr07ltX/squ/fC9zV4Xs7J+kWddjoKUpWg8wVpLtVI9tjYdZhz9tvbaVJ/V24T/bFbtrTWsSftDW7Ta17cSEPPSXE+XDwlJ/4DVdny4NWj2tT9Mv8jcaEhKEpHQDaoFr7lK8S0wuk+O4W5j6fZIqh1StzccQPgQniPzAqf1zR227qoIx6yJJAUXZS9j16JH71Vy2TjBs7oaldqIxfBmuxrjSIWIz8meb/AMouL/ctqI5hpvy+aifurflRDRi2ptOleNw0+EBt0/NwcZ/FRqX1KuPTFIjrLfNvlL3K0pSpmYVFdV8lGJafXe+JUA8ywUsb7c3Ve6nr6kH6VKvGtA9tS7KjYZaLQhe3tkwurT+kltP/ALlpqFkumLZp0dStvjB92YvsZY6XhesymJLjzjnsjDiuZ8FuH8U10lWuOzbbUWzRmwoCAlchtclZ/SK1kg/1eH7q2PXKo9MES11vmaiT9/0FKUqwyClKUBx72rXTdNbolt337qLHjbf0lKV/frryG13MNln/AEbaU/cNq4+1D/z92rRHHP8AzrGZ/wB3wA/2TXYw6Cs9O8pP3PV8Q+GmmHtn8StKUrQeUU+dVpvUK1lz2BpzgU3IpnA4+kd1CjqO3fvqB4EfLxJ8ADXG8LLJV1yskox5Zobtw6nhqOjTazSPyjoS/d1oVzSj4m2fryUfQJ8zU67HGnwxHTZF9nMcF2v4TIXxJ95tj/skfUEqP9L0rl/RDE7jq/rMhV7cclMKeVcbw+r89AVuUftqITt4AnbpX6INIQ22lttISlIAAA2AFZqfjk7Ge54i46SiOkhzyz09KjupaFuadZIhCSpSrTKCQOpPdKqRV5SGm347jDqQttxJSpJ6EHkRWlnhweJJn5udnV5tjXDEHHVcKTckIB9VbpH4kV+k4r8z9QsavOleqb0ApW0/bZiZVufUOTraV8TTg8+g38iCPCu38V1201u+Ix75Lym2Wx0tBUiFJkBL7S9veSEfErn0KQd6yaaSjmLPovG6ZXOu6tZTXYzOuuaN4FpheMgDgTLSyWYKT+dIX7qOXjsfePok1zH2IdPXr3l72f3JpRg2kqREKxv30pQ5q9eBKt/6Sk+VXWb3XIO01qNFx/FWJETDrS5xOzXW9gCeSnVD9IjkhHXqTtuduscLxu1YjjEHHbLHDEKE2G209SfEqUfEkkknzNTS8yfV2RllP7DpXV/fPn2RmhSlK0niilKUApSlAKoSANz4UFRXVm7mxabX+5p+NqE4Ec/zlDhH4muN4WSUIuclFdzivWfKn8w1Fut1U6pcdLxYiA9EMoOyR9evzJqddji2Kl6nvz9t0QYK1H0KiEj+NaUUd1E9a6h7EdvSm15Fc1I99bzTCFfqgFR/eK8yn47cs+x8Qxp9C4R9kdH0pSvUPjBSlKAUpSgKVWqeFal141et2DQn7NbiZGQvs/k0JHuxgoclrPn4hPy8KjKSisssppndNQgssg3aH1wQ0LrhGNMBa1JVFmzlK5J/NWhA8+qSo+vLxrmIAlWw6mvp5a3HVOOkqWo7qKupNTDRG1MXrVfHbfJa75lcxK3EEbhSUbrIPp7teVKbtnufbUaevQ0Nx7LL9zsXQnH3Ma0sstukNd1JU17Q+k9Qtw8R+uxFTmg2oK9aKwsI+Ism7JuT7lpelluzzVp6pjuEf1TXInZIUHNYnHF/EYbx+vKuwZjIkRHmFdHEKQfqNq4z7OT4s2vseG+eDjXIiEH9LYgD701nt2nE9PQLq09yXODtKlKVpPJBqwyCc3a7DcLk9ybiRXH1/JKST+6r6tU9qfJEWHSqZDQ5wyrsoRGgDz4TzcPy4QR+1UZPpjktordlkYLuzVXYwtLkvML3kLqSRHihgL25FTigT+CPxrqutX9mXFVYxpdDXIb4JlyUZjwI5gKA4Af2QPvraNQpj0wSNHiFqt1EmuOPwOQu2NI9s1St8Fs82be23+0paz/EV1fYGfZrFAj7bd1GbRt5bJArkLXdX2t2kjGb94CVEj7fII3/AHmuygNkgbeFQq3nJmjX/Dp6Ye2fxK0pStB5QrkLtiyjK1Rt8AcyxAbAHqpajXXprjnWve99p1q2/EBOhRNvQ8G/9qs+o+XB6nhCxe5eibOvLRFTCtMSEnpHYQ0P2Ugfwq6oOgpWg8x7s0zbv86drK4rUQpFpsQSg79FKKOX/iKrc3rWktEFi5616lXgK4kofajtn04lg/8Alit2VXXxk0araaj6JfoaQ7W2E/b2GIyWGzvPtG5c4RzXHPxf1Tsr5cXnXr2Tc2OQYQcemu8Vws2yEbnmuOfgP7Pw/Lh863LKYZlRXY0htLrLyChxChyUkjYg/SuNGzL0S174Vlz7MDvX/SxHD19Sn+0g1VZ/Dmp9nybdL/NaeVD5W6/dG8tadp2qumtmI33uDkvb/uwlX8DW3vCtPXt9i89pjF2mlpdahWR2Y2pJ3BDhUAfryrcVWw3bMV+0IR9v3Z8rICST4AmuSOzgn7V7Rd0uXNQQJsoH+kvh/wDUrq68viNaJkk9GmFr+5JNcsdixvvc7vclZ3Wi38O/9JxO/wDZqu3ecUatF8Omul7JfidZUpStB5hTrWnVE3ntWe5spuxWMBY8luEnf7nBW33nEMtLdcUEoQkqUT0AHjWnezqFX2/5rnzqDw3S5GPFUrr3TfT6bFA/ZqE92kaaPhhOftj8f+ZuauQ+2Y8pepNvYJ91u3IIHzWvf91deVyb21YJazSzXAJPC/CKCfVCz/76q1P9Nmvwd/zS+/8AQ6dxBKUYnZ0J+FMFgD5d2msrUX0puLd102x2c0riC7cylR/WSgJV+INSir1wjzZpqTTFKUrpEVy323nVG94yx+amO+r6lSP/AG11Ia5l7b8BZXjNzSDwBL7Cj6+4U/uVVGo/ps9HwlpauOff9DeOkaEo0txZKRy+yIx/8JNSmoF2fLii56OY48lQPdRBHPPoWyUf3ano6VbD5UY701bJP1YpSlSKhQ9KV5S3UsRXXlfC2hSz8gN6BHHuCj7d7V6pSeY+15EgfJHGf4V2PXHnZaaNx11kXAcw2zJfJ/pHb+9XYVZ9PvFv3PU8W2tjH0SRWlKVoPLKVrfWTR/H9Unbeq/3S9xUQErDTUF9tCCVbbqUFoV73Ic62RSuNJ7MnXZKqXVB4Zr/AEc0nxjS2HPYsDs+Sue4hbz81aFubJBCUgoQn3Ruo9OqjWwRVKUUUlhCyyVkuqbyytKUrpAiWo2nmI6gW5ELKLS3M7rfuHkqKHmSevCscx0HLodhuDWr7d2T9MIs32h9/IJzXFv7O/MQEdem6EJV/wAVb8p4VBwjJ5aNFervqj0wm0jF4zj9mxq0NWmwWyLboTXwssNhKd/EnzJ8SeZrKVUUNTS7Gdtt5YpSlAKUpQClKUArTva7n+yaRuRwSFS5rTXXwBKz/ZrcIrVXahxebk2mDxt6S5Itzwmd0Oq0pSoK29QFE/Sq7c9DwadE4rUQcuMo4krq7sUXOO7il5tITtIYmJfJ/SStIH4FB++uUTuOtdC9iq9qYyO82FSEcEuOmQFbe9xNnb7tlV52meLEfWeMQ69JJrtg6spSleqfFClKUBSlK0zqprQq05D/ACNwy3i8ZC4vueLq2y4fzdh8Sh4jkB41GUlFZZbTRO6XTBFe0bq0cJhJsdhebVf5SeIr2CvZWz+cR+kfAH5+VRXQXSp7IXl6gaitLuEmYrvIseX73GPB1wHr+qny5+VSHTvQ5Dd4OWahSxfL68536mFHdltfX3v0yPL4Rt0PKtyXSbGtdqk3CSru40RlTzhA6ISnc/gKqUHJ9U/wNs9RCmvyaOXy/X2XsccdrJuzRtThCtEKNFUxDbEkMICQXDuRuB48JT+FS7sWYzHkXC7ZVISFuxQmLGBHwlQ3Wr7th9TWiMwvcnJcpuV9l/z06St4j9EE8k/IDYfSuyuzFjD+N6VwzMRwSriszFJ25pQoDgB/ZAP1rNT8dzkevr29NoI1N7vb/JtGlKV6B8sUrjPXO2TNPNdkZDFbUGJElFyiqHIKPFu4j+tv9FDzrs2oTq/p/b9Q8WVa5KxHmMkuQ5W25aX6+aT0I/wqq6HXHbk2+H6lUW/F8r2ZJceusO+WWHd7e6HYstlLrSh5Eb/fWQrk7CsrzvQyU7YcqscmZYC4VIUj4UE9VNOfDsf0Tt58ue+x3u0lg/sgVGh3h+Uoe7HEdIJPlxcW1cjdFr4tmSu0Filmv4o9mjckuQxEiuyZLqGWGkFa3Fq2SlI5kk+Fc3Ntva7axJmBtf8AI2wqABVyD5332+ayPokedX86NqbrU8iLMhuYjiBUFOIWD30gfI7FX3BPzrd+H41aMSsEeyWSKI8Rgee6lq8VqPio+dN7H7HYtaSL3zN/l/szCUhKQkAAAbACvrlVKgWpuS53ZJ0VjEsL+3mHGip57vwju1b7BO248OdWt4RihBzlhHOG4u/ayCh76FZAD+yhX/8AWuzK4vtOE6xWrOxmMXDn/b0ylSQlzuy3xKJJG3HvtzPjWz/5bdor/wDD23f7n/8A3rLTLpzlPk9nX0+d0KElhJLk6BqwyC7wrFZZd3uTwZixGi66o+Q8B5k9APM1oeRmPaPcRwt4NBZP6SGAT+LxFQnIcY13zq6RIuVQbn7Ap9AWgKabZaBOxVwpOx2BPPYmrHd6JmSvQZeZzil9Tq+xXBu72SDdWW3G2psZuQhDg2UlK0hQCh4HY1yPDP212u9z721+X/4JP/7ddC6i37Nscdt8HDMK+3I3s+zjnfBAaKdglO248K52xzDtXrLqOjN28JkPTRLdlLaUpAQoucXGPj3/ADzULnlxXuaPDoKMbJOSWU0tzsuvKS4GYzrquiEFR+gqGaZZDm98dnDLsQTj7bQR7Oe/4y6TvxfLbl99YXVbI9SIk+XZ8VwY3SC7E4Uzi8BstQIPu7jpyq9yWMnmRok7OjK/HYjPZCWJsDLbz1Mu7E7+fIr/APUre9cuaPN6w6c2qbbImnTk9iS/3/5R5CShXCEnmFdNkiugtPrnkN3x1E3JrILLcFOLBihzj4Ug8iT61CmXwpM0+IVYtc0017NEhrSnazwn+UGEpyGG1xT7PutfCOa2D8Y+h2V99brrzkstSWHI77aXGnElDiFDcKSRsQasnFSjhmbT3OixWLscu9kKVOvmcy5lxeU8q12dEOOpXVLfH7qfoN66mNah0H0+kYLluYtLYcEJx9oW95XRxk8Stt/NO4SfUVt41CmLjHDL/ELYW3uUONv0PC4x0y7fJiq+F5pTZ+o2rkTsuTzi+tMmw3JXdOSmnoJ4uX5ZCgoD/gUB6kV2FXO3aG0hu8u/fy6whK1TwpLsqM0dnO8T0db8zyG49NxUbovaS7Fnh9sMTpm8KS59zomlc5Yl2kDAjJtuc4/NZuTI4HXWEBPFt4qbVsUn5fhWTmdoCTfeK36f4bcrpPX7qVvJ/JoPmQjf8SketSV0GVy8P1CeGtvXsSbtE5a7a8cbxOzEvZBkBEWOy2feS2o8Klem/wAI+Z8jUz06xtjEcKtePMFJ9kZAcWB8bh95avqok1BdI9NbpCvz2d57MFxyiUPyaN90REkbbDw4tuXLkB0rbfpXYpt9TK75RjFVQeccv1YrT3avxJ3ItOTcobZclWdwyeFPUtEbOfdyV+ya3DXytKVoKFAKSRsQRyNSlHqjhldFzpsU49jQHY8zRibjj+Gy3gmZBUp6KlR+NpR3UB/RV/aroEVy7qroxkOLZJ/LDTXvu6Q73wjRz+VjK8eAfnI5nl5ctjWTxjtKOQmkwM2xuU1Pa91x2MOHc+am17FJ+v3VRXZ0LpmelqdKtTLztPvnld0zo/6Vh8wyG24tj0u93V9LUaMgq5nmtXgkeZJ5Vp6f2krU+DHxnF7tdZqh7jagEjf5J4lfhUUlYPq3rBdmZ2WrFhtCFcTLDieENp/Va33KtvFR/Cpyt/8AO5nr0LTze+le/P3I3dofOut001tl0vEl2TKmqekcbityELdUUJ+QSUisZ2j8ScyzTGa1Fa7ybBUJkdIG5UUg8SR6lJV+FTjGbTHsOPQLLFUpTEGOhhCldSEgDf8ACsiedT6cx6WZ1d0XeZDs8nM3Y2zNlpM7CJzwQtazKhBXLiO2ziPnyCtv6VdM71zXrVojdouQKzLToLQ93vfuQmVcDjTm+/G16b/m+Hhy5CmLdo252dCbVnuNyvbmhwqeZR3TivVTattj8vuqmubr+GZ6Op061b8+jfPK7pnStWN9usCyWmTdbpJbjQ4zZcddWdgAP41pab2lLA4nubFjl3uUxQ9xohKRv9Co/cKiV2x3WHWaY0q9xxjthSvjbYeCm0J9eD41q9VbfSpu1f27mavQSTzc+le/P3I3LoVfLjk2ISsgnyH3EzrnIcjIdP8ANMhXChA9BtUlzuWIGFXqYTt3MB5X/Aa+MDxyPiWJW7Hozyn24TXB3qk8JcO5JUR6kmtX6uXvVS5sX/FrNp8p+2yUrjNTw8klbahsVBJUNvGpNuMdyqMFbf8ADhLPfbY172J4pVmd9l9Q1bw3v/ScSf7tdX1yVo7ZtXdN7hPkw9P3pyZzaUONuuoTsUkkEEK9TXS+CXG+3XGo87I7Om0XFxS+8iBzj7sBRCefqAD9ar07xDDNXiq6rnZFpp47+xn6UpWg8sUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBXy4AUKBG4I5ivqh6UB+a925XWWAnh/LL93y941OOz7lkTD9TYFyuCuCG8FRX1k8m0r294+gIH03pr7h0vENRri0tgpgTXlSYTgHuqbUd+HfzSTwn/8AkVr4V47zXZ9D76KhqtNjs0fpchYWkKSQpJG4I6EV9Vxhp/2gMqxXHGbI7DiXVmOOCO5IUoLQgdEkg8wPDyFSFrtSZGk7u41a3B5Bxaf8a3rVVny8/BdUm0ln7zq6sJmGVWDEbUblkFxahsdEBR3U4rySkcya0DYdbtUM4lm34hiUAPj43dlOIaHmpSilI+v41n42h99yy6N3rVHKnp74HuxIh2Q2P0QdtgP6Kan5rkvgRR9iVMv5iWPZbs+Uap5Rqhdnsb02t67ZF22lXiUPeZbPLdIHJKj4dT8uomulukGOYJNVdWnJFzvC0lKpsk7kb/Fwp8N/E7k+tTLGcesuNWpFssVuYgxEcwhpPU+ZPVR9TWVFSjDvLdlVupW8KliP5v6ioF2g5ghaO5G73nAVxu6Tz6lSgnb8antcz9szMh/kOExF79Jk3Y/MNp/er+rS2SjBs7oKXdqIxRznZYEm63iJbYTSnZMp5LTSB4qUdhX6PxWksRmmEDZLaAgfIDauPux9Yk3PUx25vNhbdriKdTuPhcV7iT9xXXYwqjSRxHPqej47d1XKv/yVpSlazwxSlKA+HW0OoKHEJWk9Qobg1axrTa4zvex7bDZcP57bCUn7wKvaUO5YpSlDgpSlAKUpQClKUApSlAKUpQFKU8ajKs5xkZyjDBcUqvK2y4GUjcDYb8JV0CtgTt5UykdjCUuESelKUOClKUApSlAWk222+YQZkCLI26d6yle33ivWNGjxkBEdhplA/NbQEj8K9hQ0O5YpSlDgpSlAKtJlut8z/nkGLI2/0rKV/vFXYpQZa4LeLChxUcEWKwwnybbCR+FXFKUDeRSlKAVbTIEGYnhlw48geTrSV/vq5FKBPHBbRIEGINokOOwPJppKf3Vc8qUNBlvkUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAjGpGGWnOcYfst1aTuoFUd8D3mHNuS0/xHiK5bvPZv1BhvrEH7OuLQPuqakcCj8wvbb767KptzqqymFm7Nul8Qu0qxB7HGNm7OWoc2SlE1mDbWd/ecdkhew8wlG+/4VtKz9mHFo6213K93OaABxoQEtpUfQ7EgVvzeq9ajHT1rsW2+Laqz+7H0MTjGP2fGrU3a7JAZhRW+iG09T5k9VH1NZWnOq8tqu+h5zbbyxSlK6cKGvz61evv8pNS79d0r7xp6YpLJ820e4j/AIUiurO01qCcMw37PgL2ut2Stlkg82m9tlr+fMAep9K597OOnQzrLjKuTZVZ7aUuyt+jyt/db+u3P0BrHqH1yVaPoPCYLT1y1VnHCOg+y3ibOO6ZRLguMpq4XYe0vqWNlcG5DY+XDsr9qts15oSltCUIASlI2AA2AFfdaox6VhHiXWu2xzfcrSvhxaW0la1BKQNyonYAVGXL7dL1xN4rGaMfbb7VlA9x/wDpJHvO/Pkn1NSKsEorzcfYbTut5tAHipQFRZ7CUXHhXf79ebksb7oRKVFa5+SGin8SashpFpwHO8OKQnFeJcUte/8AWUa5lk0od2TVp9l5IU0824k9ClQO9eu9a3vGjGFSEKes0R3H7gNizMt7ym1NqHjtvtWBxjN8lxTIIdhy6ZHyGyTJPskLIomxCXuLYNPBPIK4uX+PPaPVjksVKmswe/obnpTcUqZQKUpQClKUBStda2ZtkWB2du+W6026fbUqS3IL0hSHUrUrZPCkDYj61sUVp7tdq/8AqkLA+J64MJH/ABH+FQm2otov0sVO6MZcNmTZyXVz7NauSsHsUphbSXe4j3RXfFJG+wCkBO/1qR6bZxbM4tT0mE0/ElxXSzMhSBs7Hc/RV9x5+lSSA2GYLDQ6IbSkfQVpq07WPtX3GHF2RHvVpEh5A6F0eP8AwK/rGuNuLRZGMLVJYw1uTPT7L7xf8uymy3aym3JtMlKYyiCC62oqCVHfruEhQI86nJIHOsTYbFEs79wkMreekXCSZMh51W6lHbZKR5JSAAB5CtU9qrP5WM49Fx6yTFs3a6K3Wpse8iPzB2PgVK2HLwCq65dEcshCr7RaoQWM/wDMgmtPaAvaMhl2XCpDUWFGJaXN7sLcdWOpRvyCfLlzqLdl223HIdZGbq5IUtUJDkyU64rdS9/d6+JJV++phk2ldgw7s6zLleIja8ieSy8qQsnjaWpadmk/IEg/Wpn2S8H/AJPYc5kU6M41crttwhwbFEdPw7Dw4j73y4ayKE5WLqfue3O7T06OSpW/y59fU2RlOUm13GPZbXbHrze5LZeRDaWlAbaB2Lji1ckJ35DxJ5AGsVjuW5QcvZxzJ8TTbTKZcdjTI0sPsr4NuJJ5AhXPxqNHI4+J9oS8RshV7NEyGHFFtlu/AktgpLe/5u6io/Ph8629yOxGx9a1rc8OcVWllcrki2Q5XJYvKrBjtncvV2bbS5IT3waYipV8JccO+xPgkAkjnVthmU5BPyGZYMlxn7ImMRxJadakh5l9BVw+6dhsQfA1E8GyONYNZMvxfIFpizrrNRMtzzvJMlsoCUoCvMAbD5KHhW3tue/KieXkWRVezXKW5rmNqZcHs2OIfyHuiLklsSFpMpjhQwVBPeEhW23Pp19KnV7ulvs1qkXS6y2okOOjjddcOwSP/nw8a1tiPBO7SGXy+pgWyNF3/pe9/Cvu6lOc6zCwv7O2PFmkS5LPVL8xf80FDxCRudvP51xSeCcqo9XskmzItZhmt5a9sxrBT7AfeZfuswRlvp80tgKUn04tq9LPnl7n2q5qXg1xRdrXKTHkwEyWt9ijj7xK1EJKdtvvFT7kKxmQrbh2C6zEpShSYrri1gbElKDsT91Sw13KlKL26SO6Y505nEZycxjs6329PElEl95shxaVbKSEpPFy589tuVXeo+XPYbZzdzYZlyhNJUuU6w62nuEjbYkKIJ338AawnZviKiaN2LvBst9Lr6vXjdWr+NXuuPA7p5Jt6uf2hKiw/wDePoH7t64m+nJOUYq/pXGcC7ZtebXiKsimYRc20NFan4/tTBW0ylPF3p9/YjryHPl0rCMavPmxM5DIwLI27K633vtjaW3Qlv8ATKUq3A9TtWZ14kew6N5EtJ2/yPuh+0oJ/jWQw1qJZtKbQ3P4G40SzNGQV/CEpZBWT+Nc3zjJ2KgodTXczdhusC+WeLdrZITJhymw404noof4+nhWO1CyeLh+HXDIpaO8REb3S3xbd4skJSnf1JFRHsxQ5kPSG3e1pWhL7rrzCF9UtKUeH+J+teuokJOZ5OrFiAuDa7c7NmAgEGQ6hbcdJ+QLi/mE13LcckfLjG5x7Jk0xK4v3jGLbdZCGUOTIyH1JZUSlPEN9gT86iuoWpAxm6C02rGrvklxS2HpDNvaKhHbO/CVqAOxOx2FU7PFw+0NH7CsklbDKo69+oUhRT/CprFgQ4s2ZMYjpRImKSqQ4OrhSkJT9wAFdWWtjjUa7GpLODVjGvmMssk3uxZHaHh8bb0E7D67j91Su95jc7RhMbJX8VmPhbSn5Udp9sLitbFQKuIjc7bbhO/PerS/NpzTNmbAkcdksTqJNzUPhflfEzH9Qn+cV+wK9depJi6QZI4DsTEKAfVRCf41HMkm2WdNcpxUY8+5k9Pcnfy2yIvCrHKtcV5KVxVPutrL6CPiAQTt9dqtb/mbrV7Xj2NWh2/XdpIVJSl0NMRAr4e9cPQnrwgFW1Y5V2GB6DRLkpI7y22VhLaCORd7tKUg/tEb/WstpXYDj+Gw2ZJLlylp9ruLy+a3ZLnvLJPjsTsPQCu5fBBxisyxtnYxEXP7laskgWLObCizOXFXdwZseT38V5z/AEZUQkpV8x41m9QsplYnajdEY9Ou0NpC3JTkZxsezoT+cQo7nx6dNqjnaXt7c7R+7PEfloJalMLHVC0rA3H0Kh9a98wuzszQJ+5vHieuFlbSrbxW+hKP3rrmWm0S6YNRnjvhkxxm8wsgsMK9W5fHFmMpdbPiAfA+oPL6VGc3zqfjF6h28YjcZ7c59MaHIZkMpS88pJVwbKVunkDzOw5VF9H1LwfNrtpfMdcVF2+0LI46ebjSvjRvtzIPP6KqT56lEnULA4Kxun22VL+Rajq2/FYom2jkq4wsxyuUfGf6gy8Ns8a7XDE7i5DW22X3G5DR9ncWrhDZHFuTvtzHLnUpxufMuloamzrS/annNyYzziFqSN+RJQSOY51r3tMO8WJ2W27b/aF9iMEeY3Kv4VtRACUhIHIAAV1NuTRGcYqqL7vJ9UpSplIpSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUBSvCbKjwoj0yW+2xHZQVuOLVslCR1JNe5rm/tU5m7eZkLTbF3HJkx54GciOd91fmM8vHf3iPDZPrUJz6I5L9Lp3fYof8kam11zFWo2pKnrSh12G0Ew4CAk8Tg4j73D5qUo/ThrrLRLC0YNgEK0LSn25wd/NUPF1XUb+SRsn6etRjQzRi2YVCYu15aanZEocRWfeRF/VR6+avurbw61VTW0+uXLNuv1kJwjRT8sfzK18OLS2hS1qCUpG5JOwAr6qC6py3Zkyw4Wwoo+35SkS1AncRGk946n04wAj9o1e3g8yEep4L2G2rNE+2zUqRj5V/ksU7j2wD/tXP1D+anxGxPUCpYhKW0BCQEpA2AA2AFUbQhttLbaQlCRsEgbACvvrXUGBQ1T61Cs61Lx7DbrHt94YupLqONT8eEpxpsfrKHy6J3NcbS3Z2EJTeIrLLjV2/s43pzerm5ISw4Iq22CV8JU6pJCQn13O/0rXWlmO/yx05wyL3PsuP2taZjylLHezZKSriSEp+FAcKveJ4lbDkAd69rvnmAajXiFbpGQwI9it8lMl5uZ+ScnOp34GwlYBDaeqieZOw6b1IdLcaTaM3yW5WRl2FjE1LRix1cm3H9t3HW0+COYHrz25AVX80s9jWv4VXS8qXP7Efytq3HM88lT73cLe3b7dHdjd1cnG+7fUhauJCOLYkkIHDtz6bc6ydgkXXML5aMfyF6S03b7DGn3RhClNKkSXtwlKynY7JCFkp/SI8qjGQwxdsnzvILZEEq62O4QZ9vKmObqGGgHUJJHNJ98cvECpdDvEC16kvZbMW6zZMhtEdMeWtpQS260pZKHOXuEpXy3/RNN8iWOnbnH+DEZI89Zouo2LMTJogwrIm524mSsuRlqQ5ulK9+IJC20kDfxI6Vk9OWm8retEpm4SF2vHGEM8Tc1wmZNUhCnFOe97yEeAPVRV4Co/mS1zse1AzEx5LcW8RGbTa0KZVxyG0BW7gRtxAKK17bjones/YPZ8OzuC5DaKMdya3NJCmWT3bMtlICSQB7gWg7bnqpIouQ0unbn/SyYGzsWCdd8vg3PIbhHuK8hXBtiEXR3vGeJLfCUt8Y3SFqUflvV1kEe3nPMsF4v0+I1brJGdStFxcZCX1Be7iUBW254E8v8at8TvmJMxL3cblDXJuqsgfnQmhEWHnSFjuuFXD0Ow9OdWeSW85Dl+eXOJB7y82tNtm20LZ3JXHSoutpURsQSSg7eYp2Or5nn/uDbum8m7TMBscq+d59pOwmlyO8RwqKikc1DwPmK112ryXMax6CP/iry0jbz91VbWx26R71ZId0ihYalNJcSFoKVJ36gg8wQdxWke0vf4UnIcYtDDVwfctN3Zl3DuYbqkttjhPJXDso8KjyG9LPkIaVZ1CZvxvkhI9AK0tbR9r9rS4SGffatNmSy6R+as7ED/wAQ/dWcuWrsWVFXHwzHb7f7oscLLf2e4w0hXgpxSwnZPy/DrV7ovhE7FoE+65BIRKyO8ve0XBxPMIJ3IbB8QNz6c+XIUfxNJCCdUZSly1hGwvDnXL11trmqPaeWbepLlqsS2vanFjiRwsqHEkeql7p+8+FdPucXAoJ24tuW/nXIumGUZVptqPkFsmYjMusq6PbLZZQUuKcClKSpB2O6TxK+8Go3NZSfBf4en02Sh82Nvv5J520Xlqx3HLYmQltEictSkE8jwpACj6DjP31vDG4pg49boSnu/LEVtsub78fCkDeuLddLfqTNv38oMxs82KxJJ9kb4w43HRvybHDuEn57E1tXs32vUIwHstvN0nqt0SA7Ht1vkrWe/wBkhSTwn8wEbA9d6hCxux7GjUaVR0cH1rbP4s3TqBhljzixLtN7jcaeZZeRycYV+kk/w6HxqD6F3K/2m/3zTXJJSpz1kCHYMs9XIyvhB+W6fluR4Vk8c1mwy4WVuVcZy7bcEtj2iA6w53yV+KUpCd18/wBHerC1JvcRWX6qPWZxuXJjJRbbc+CHRFZG/vgcwtfNXD4Vbs5JowRU41yrmtu319iTao6fWXPrQI9wSY85jcw5zY/KMK/inzFYTQS+36Xbrvi+UL767Y7L9lckb7982RuhXryHXxG1XcHWLBptqTKZuD6pKgB9niK4ZXH+gGwOZ35b9PWvPAosjHbXkWb5RHehyrzLEt6K22p5yMyAENNlKASVBO2+29d2csofEq3XYvp9TH6NFuZqLqRd08yq6oi7/wDdo2r50MX3+Y6iyHgPaVXvgVv14UghNWXZyuTAfyKJJjXGNcbldpFwSl+E6hJaURseIp4d+fTfevq8e16Z6qXHKnIUqVi2QoR7e5GaLioT6eQWpI58J3PTz9ADFcJls95Th3wsfdg3HUS1klqhaWZJJQdlJtzoT8ykj+NYy46tYimIPsSQ/kE9wfkIVvYW44tXgDsNkftbV6XGx5Bk+jMqz3ghu+XCCouJURs26o8SUbjwHJO/pU28rYywg4STnssmW0qh+wabY5DI5tW1gH58Aqx1KAmXLFLPwcftN5beUnyQylThPy3CfvqPYDqfj8DFIdqyqUuy3q2sJjSocllaXCtACd0AA8YO2/u79azeJom5LlSs0nwn4UFiOYlljyE8LqkKILkhSeqePZISDz4U77c6JprCJThKM3KRhu1G44dKH4TR2XNmx4w28eJe/wDCsHktuu0bPsbxjNchk3XGLo2ptppDKIza5KNilt3g+JJHQeJq47RV2bel47ZGY1wkGNeI02f3EJ1xKGEk7q4gnYnryG59Kkupdob1E0xU/Yi+ia0RNtbq2lMuJfbJ25LAUnfYjnt1BqDWWy+uXTXFPht/dnG5OJLsS2Wtx9ZbjRIjJWo7BKG20jc/IACtT4R/9Jy403IrdZsaU3f5BnpM+Y8h8NKADSFJSggbICeh8awuS6jPZLp7brFcLRe4FwmyGI99Cbc9szHCh3y0kJ5hQG3CNzsoit42qTFk2qNJhpUiKtpKmkqaU2Qnbl7pAI5eG1T+Z7FLTpW65NYdmxcyLasmsFxbZalW29vBTbKipCAvZXuk89t+LbepnqFkEiyWtiLa20yL3c3fZbaweYLh6rV+ogbqUfTbxFa30/yCDA1oy11uPdBbL2WFx31299KO/QCFg7p93qeZ5e71rFQdTu7zm6ZNc8Kyie9ziWoNQvyceKNiVDiIPGtXNXLoEioqWI4LZ0udrkl6M3XhthYx2wMW1pxT7gJckSF/HIeUeJbivVSiT+FQbtQqWrSl6E2dlzZseOPXiWP8Kw83XOephSLZpvkjkpQ4WhIa4EcXhuQDy32rx15u778fFLO/GmyJsW5xJt09lguqbQ2kEqIIBB5/mgk0lJOLSI1VThdFz+pk+06kMaTRmD7rPt8Rtzy4QT/gK223/Np28qhWoFljakaXS4MBSh7Yz3sNb7S2iHEndPElQCk7kbcx0NYbCNUrOxjzFvzOUbHkEBsMTI0xBQpxaRtxt8vfCtt/d3613iW5BpzqwuU3+Zd9o2T3ekt0ht7qk3FbMOO2OZW4t1Puj12BqucxBbMHxXGFAOJeudst69vFLa0rV+DRr4tzMzP8tgZBLhSIeNWdZetrMlBQ5NkEbB9SDzShIPuhXMk78qstVslhxM+xOG+xcXI1umrmT1MQHnUtjuFpaO6UkK95XhuRXXzk7FPCguVlntr5Y5irPBzayI/z1jL3tbfCObrH/atnzG3Pb0I8aubReoOWah4xc4R4mEY/JnN/ql1xlGx9RwqH0NTuHIjXS2tyWkqVHktBSQ42pBKVDxSoAj5EVrDRvDJeJagZZGdDyrY0hhNpUoe4llxbrikJPoo8641iW3c5GSlU0+Vx9H2PrW5Qk53pvaFJ3S9eVSCP+6SP/fW1wOVaP1ByKC5rpjM16LdF22wtyUSnm7a+tKHljYAbJ974U807jnW7mlpcaS4nfhUARuNjXYvdnLliEF7fufdKUqZnFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgKfOlK1tqzfM+xq+Wu74zZl3uzBpablDQndYIIIWkj3gdt/Melcbwskq4OyXSjZW9DUR0+1BxjN4KX7POSJAH5WG8Qh9o+IKfH5jcVLd/Wiae6E4Sg+mSwwPlXw4tDbanHFBCEgkqUdgB51HM8zfHcLtL0+83BltSEktxgsd68rwSlPXn59K0DZJ+pWvFzfZVMVYcTQvhf9nSQkj9Dfq4r5+6PIdKhKxReO5oo0krIucniK7/49S51h1qvF9vasM03Di+8X3C5kccTr6unC1+in9bqfQddgaC6SR8JifbV64ZeSSk7uOE8QjA9UpPirzV4/vk2nOmOJYIhS7LBUuWtPCuZIVxuqHlv0SPQAVNfGoxreeqfJbfqoKHlULEe/qytKUq4wFBUZu+JouWe2XKnJ7yDaWHm24qUjgWpwbcRPoN/wqT1SnJ2MnHdFaUpQ4K+XEJWkpWkKSeoI3Br6pQGPbstobe75u1QUOb78aY6Qr79qyFKUDeeRSlKAUpSgFKUoBTYeVKUA2HlSlKAV8lKSsKIHEOQO3OvqlAfDrbbqChxCVpPUKG4r6AAGwGwqtKA8fZo3f8Af+ztd7/pOAcX317UpQHiiNHQ8XkR2kuq6rCAFH617UpQCqEAjYjeq0oDxYjx2N+4Yaa4uZ4EAb17UpQHkuOw46l1bDanEfCsoBKfka9aUoBsKUpQDYeVKUoBsKbDypSgGw8qbClKAV5Ox47riHHWGlrR8KlIBKflXrSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKA0bqZoBEvl/fyHFbwqyT31lx1opPdKWeqklPvI36nr9KwDejmshb9mc1LCY3TYTZB5fLaukapVTpi3k2R8QujHpznHqkzRGMdm+ytTEzstvs6+vAhRaTu02T5KVuVKHyKa3ZabbAtNuZt9tiMxIjKQltppPClIHpV5VDsKlGEY8FNuotu+d5K0puPOm486mUilNx503HnQClNx5im486AUpuPOm486AUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoC2uEtqDCelyO87plBWvgbUtWw8kpBJ+lYPT3MrZm9nkXW0tyERmZa4wLyOFSikA8W3gPe8edZO63yy2p1tm53aBBcd/m0SJCGyvw5BR51r7s3EfyZyHn1yOb+9NRzvgtjBOty+htKovkOb2iy5ZaMZkNy3LhdXeBkIZPdpHP3is8j06Dc1lIGQ2C4zlwrfe7bLlI3KmWJSFuDbrukHeoHq//wBJGmn+1nf/AC6Se2wqgpSxL0f6G0D0rgfOcyy1jM70yzk96bbRcH0oQic4AkBxQAA4q74PSvzvzZxLWoV5dUy28lF1fUW3N+FezqvdO3PY1m1baisHseBQjOyeVnY+05jnCo65CcmyBTLawhbgnPcKVHfZJPFtudjy9K+Bm2ZkgDK76SeQAnu8/wDiraOqE9u59mbD7g3bLbbDJuilOMQGO6a3Sl1IIT57AdTWC7PFnbffynJS0l2TYbQ4/CChvwPqCuFex8QEnb1rLiXUo5PaVlXlOxwWzx+eCPXS66pWqI3Muk/MIMZw7IdkOyG0E/MmrO35Vn1xmtwoGQ5HLlOnhbZZmPLWs9eQCqm/Znu0q8ZrKxG+SH7lasghuiUzIcLgLgTxBY4uiuvP5Vg9NolzxzUy8rtjDkq44/FnGMhDRcKnUfkke6OauaulN3h5GYJyjKKylk+ZQ1ihwZM6e/mEGJFa715+VJeaQlO4HVSuZ3I2FYOJl2dzJTcWJkeRSZDh2baZmPLWs+gB3NSTUjUfU+8WVWPZihyJFkKSstOW4xlOcJ3HM9RvUbxHM7ricGUnHkswrlKWOO5cAW8hoD+aQFAhIJ5k9TyrkpJPZsnXW5V5cI59uC4u+RajWeUIt2vWUW+QU8QbkyXm1EeYBNbQ7J+SZDddUlxrnfbnNY+znld1IlLcTuFI57KPrVpqrkbuV9nXFbzkXdu35dycaZfCAlTraAoLVsOm+yN/XarTsdf9La/9mPf2kVZDMbUsmTUdNmjsk4JNZX4HZYoat50uLBirlTZLMZhsbrddWEISPMk8hXhaLvarwwp+03OFPaSeFS4z6XQk+RKSa9I+QwX5oKxrt9srN1Tanrvb27gsjhiqkoDqt+Y2RvvS63yzWlxpF0u8CAt7+bTJkIbK/lxEb9aDDMlypUZ1At8W5WyAJOQLszTFxjyA8h0I70pX7rW5P5x5ePyNSCS+zFjLkSXm2WWxxLccUEpSPMk8hQ7jY9qVjbPfLNeG3HLTdoFwQ2dlqjSEOhB9SknarxqTHeaU60+042kkKUlYIBHXc0OYa5PalW5mRPZFTPaWfZkJKlO94OAAdSVdOXOreBeLTcHgzBukOS6WUvhtp9Kld2r4V7A78J86HcMv/rSo1gVujWxi7tR7+7eu8ur7zqnHQsxlq4SWeXTh5Hb16VkWcisD10NqZvltcuAJBiplILoI6jh33rmQ477GV5+VKtZs+FB7n2yWxHL7gaZDiwnvFnokb9T6VaRcjx+VFkyo18tj8eL/AM4dbloUhn+mQdk/Wu5OYZlfCnhVnabpbbvE9rtdwiTo5JAdjPJcRv5bpJFeN3vtmtBQm63aBALnwCTIQ3xfLiIoMPODJUrzacQ62lxtaVoUAUqSdwR5ivSgIpjmc2e/5ddcbt6JftFrQlUhbrJbTuTtwgK5n57bc+VSutV4d/1jM4/2fD/sJqf3DIsft85ECffLbElr24WHpSELVv02STvzqMXtuW2wSklH0X6GVpQdK8pL7MaOt+S82yy2OJbjiglKR5knpUio9aVj2r1Z3Yz8lq6wXGI43ecTIQUt/wBI77D617Qp8Kcwp+FMjyWkkpK2XQtII6jcUGC6NBWMtl+sd0kuRrbeLfMfbG622JKHFJHmQDvX3d71aLOG1Xa6QYCXSQ2ZMhLXER5cRG/UVwYZkKoajma5jZsTtcWfcpCSiXIajxwlY/KKWoDcEnbYA8RPkKyce92eREflsXWC7Hjjd91EhKkNct/eUDsOXnTJ3peMmR+lPpVhAu9qnvFmFcocl0NJeLbTyVKDahulRAO+xHQ+NeMXIrBKuarZGvdtenJJCozcpCnRt190HflXcjDMrSleT7zUdlb77qGmm0lS1rVslIHUk+AocPWlWFpu9qu7S3bVc4c9tCuFa4z6XAk+RKSdjXwL7ZTdfskXeAbh/wDdfaEd95/BvvTIwzJUq1mzoUJTCJcthhUhwNMpccCS4s/mp36n0r5hXK3TYRmw50WTFTxbvMupUgcPxe8Dty8aDDLw0FY+03m0XdLhtV0hTw0eFwxn0ucB9eEnavmZfLLCdkNS7tBjritpdkB2QlPcoUdkqVufdBPQmuHcMyNKtrbPg3OIiZbpkeZHX8LrDocQr5Ecqwljt8aLm9/mN5A7MkS0R1OW9ToIhhKVAEJHMcXPr5UCXOSSU351FbZn2MTr1dbWm7Q2l2x5DC3HZCEhxZG5Cdzz2PI+vKsBqPDYs2WQsyt2RwLbd0s9w7BuE1LLFwYB3KPePuqG/JXTfbemfQkq3nD2NlUrxiPJkRWn0lJS4gKHCoKHMeY5GvaukBSlKAUpSgFKUoBSlKAUpSgFKUoBSlKAUpSgFKUoBVFHYGq0PSgNd6RohZRhknI7pFYlyL3KkmT3yAsBtDq20Nc/zUoQOXnufGojo3YUT9Hcux2JcV2ppV4mx0SUkbsoHAPu2Gx9CazmM49nWD3i5WjHoVtumOzpS5URciUWlQVLO6kqTsSpPlt+G9Y3HMAy9rS7L8RnGLHl3OU/IjTG3+TpcI5KSB7gPD5nkqqt9tjbmKziWzaaMbqBdcflXXAF43EcPsl+ixkXSPDLUdaCrgW2hzlxg/q7p686lOr/AP0j6af7Wd/8sVYZDjmdZDY8bQmxWq1OY9MjSkw1TOMSlMkDhSpKdm07DlvuflWV1LseXXjJsPu9otMB0WV4y5Db04o4lqSEltJ4D0G/vH05Ued/uEXHKWezNleFfnXn/wD9ub7/ALSkf+aqv0QYUtbCFOthtwpBUgK34T4jfxrk/Jezvnd0yq4z2n7OiNKmuvJJkK4ghayr4eDrsem9VamEppYNng2orosk7HjYw+bf9VHBv9puf+tUb0Mz6PgWTSnrnDcmWi5R/ZprbY3UE+CgPHxG3ka6DyTRZ24aOWbBY10fTItL3tDcpbKOF1Z49wU8fuj3/M9K1ZbezPmrk1tFznW6PFJ99yK4XnE/JKuAfj9DVEqrFJNI9KnWaSdU4WS2bf6km0Ajaaxc7vOQYui8uxLdBW+7LuAShqGlR+BI6qJSDzPgmtLWjUC+WHOLvldgdYYl3F15RLzIc2Q45x9D49K3tkOkObx8QVhOGM2u32Z1feT5Uicoyrgv9fhb2Snp7oqL2nsy5G5CeN2ujESQlY7r2TZ9K0+O4VwbH612cLNlFEaNTpU5TsnnOFvvt7l61m0nVDQLMv5WRoirhY0oejymm+DdR5pO3grkU8uoNaGxuzzcgvkSzW9IMiW5wJJ+FA6qWo+CUgFRPkK6UvWi+UwdPf5F4f7II815Mm6zp8nu3pKk/C2EISpKUDYfnH99ZLRfQ4Y3b7wcvionTLi0YgER/wBxEc7cQCvdVurx9ABSVM5yWRVr9Pp65uD5eyOedTr9GvV1h2ix8a7DYo3sVu2H86lPNx8j9cgq+W1Tfsdf9La/9mPf2kVt7MtG4EXFLhB06x2HbbrcWxFely5Kvcjk7uJQd1bFWwT0HImsN2ftHMtwXO1Xu9OW1UUw3GQI76lq4lFO3IpHLka7GmcbE2Rt8Q09mklCLx9eWbV1IhW1SrNer1eG4FttMz2l5l5AU3JUUlKE7dSoE+6Bvz8OlQrD5kWR2jp7tst0y2RpmOpddbfjFjv1pf2DvAefTluQD1qVaqWG+XObjV4ssZmeuy3H2pyC68G+/HDw7pUeQUnflv5msfDx/MDqxGzeVBtqY8i3fZz8RMo95FbC+ML4uHZxW++4G23r1rXLOTwq3FQ3fKZD2LlFx/JF4bqLYXENS72qba760j3X3VPcaCpXgock+idgRtzq+1KuJxLN75OyzHnbviWQRmIypjKONUEJSUlBHgColXhzI251mXcazG5Y8xhV6hQ5ERqYh43kyeIllD3eJAbI4g5sAjffbx3rI3+3ZmiXklti22FdrXfP+auPSuD2IqZS2sOIIPEndPEOHzPnvXMPBPrhnLX13/NEe1vhWd3DsIuEHaQ2xeLeiFIKiSWlEc/XcBNZzNHk3jVzGsTnBLlrTDeuTzCxuiQ4khLaVD84J3KtvMCrbUHCr47gWLYzjbEaYbNJiOrckyO6ChHTsByB5qP3VcajYnkd6fsGX497Nb8otG5EZ53jadbWPfaKwPx28T06g85f3CEoYim/X/RKbfiNht9+mXuDAajvzYwjyUNICWnUgkglIG3FzI38qgWhMOKvBMsgLjMqiC+XBruCgFHAFbBPD0228Kl2JOZ7cJrcvJotss8VpBHscV0vuPLPLdSyNkpHPYDffxNRvHcezTE59/s9pt0C4Wq6zXpsac9K4DFLvNaVthO6+fTh+pFSfKK4v4ZRb32/IieLWyDceyZLamR0uojszH2gSRwrQ44Uq5eVTLRzB8Zj4nZMiRb+K6yrQht+St1alOJWkcQO529OXhWOxjEcvtuhdwwx63Qjc3EPMMq9s9xaXVKJWo8Pu8PF0577VNNM4d8tOEQbRerewxLt8dEdPcSO8Q8EpACgdhw7+RqMVxn0J3WbS6X3IRoDbEqwbMbPb3lwEG/TY7DjZ3Uz+TbSlQ9R/CozqfLx6FplZrVYUruEuyTIbIvEaGUtIdQpKVnvuhUo778JVzPOphp3ieW23HMtsV1hw4f2y/Klx5TEvvO7U8gJCFJ4QeW2+4rFT8Nzq86TwMKNotdrctSGNnly+8TMUzttwhKfc4iNyVePhTD6cE1KPm9TfcudfbPbp2V6fyZMYLdevCIriuIjiaI4ig+hIr4yHGrFH1/xuExaorMOfbH1yorbYSy8po/kypse6rh38R4DyrMalWLMMgdw+fbrPbxItM1M+Uy7PIAUnl3aVBHPfc+9t4V95NZcuk6qY7lcGzwXIlvhLYkNuTuFZU78XD7u3u7Dn40a3/AjGeElnsy1wSJGsWuGY2q2MpjQHoEWYY7Y4W0uncKUEjkN6vNFlR8msF2ya5R2ZUu6XGS26XUBWzCFlDbPP80JA5dNyT4192+yZVF1oumSm1wl2efFah8ftn5VARz7zg4duZJHDv5V843Y8mwW5XWHZ7W1erFPlrmRkCUll2I4vmtCgobFG/MEcxz5V2Of1OWOMlzvhf7PLRZbluv2ZYghSzb7PcUqgoUd+6adSVd2PQEHYetbOqK4BjkiyJulwuK2nLreJhlyy1uUN8gEtpJ5kJSOviST41KRUorCM9slKeUasw//AKxecf7Ph/2E1icqYx2zYZl+Oylu5Nd5HtU6QpmH3i46lpKmy6se6jh2G25B2HIVnrBYstg6z33JnbVBNpurbUdKkzfyrSWkgBwp4djvt8O/LesdZMVzSBZcnxEQICmLxMlPJvTknfdD42PE1txFwD129eXOGNjRldSefT9CYaOvPSdK8YekOKcdVbGOJazuVe4OtSeUwzKjuRpDLbzLqShxtxIUlST1BB6io1pVbLvZcFttkvUaMzIt7KYyVMPlxLqUDYL5gbb+VSs1ZHgzWtdba9TRunTlvwyyagYlMgx3RapS3mWVNbmUy+PyKVbj3tzsj61fZLbGsSxLBdPo6UssXW4sRrkpvl3yAOJ1JI5++rYb/o7ipHkGCv3DVq05Uy+G4CI3DcGQrbv3GlBTG48QFe9+wKyGqmJPZXZIot8pEO722W3Otz6xulLqOgV+qf8ACodLSNDsjKabfPP1I/r5bo9rwpjKbUy1DudgksOxHmUBJSguJQtvl+YUqPu9OQrDaiXeZjGXu5Re8bXe8Tu9rZjSHW0BbkAAqKhsfzVce56bkDnyqT322ZPnFtjWK+2ZizQPaGnbitMsPF9Lagvu2gByClJG6lbct+XOve7xMwt9/vS7dbId6tV2abQwy5J7r2NaW+BXElQIUhWwPu8+XTnRrO6EJxSSlvyQnWGBjczTjBnbayzMtwukFmG46njUWFkAp3PgQBuPSpJrNi+OxdGr7FiWaHEYYaVKabjtBpKXhsAvZO3OvjKtPbidKrFj1ncYkXCxyI0ptLiu7bfW0rdSd/zQdzt9KyGYw8xyjTe8Wxdjgwp89sMMR1TuPu0n4lLWE7b+g3+dcxnOx1TS6cPZMx+B6fWFOBRblbUuwL1dLA2w7cg6pTg7xpO6uZ23HLptttUK1MnY/HwrF4OOtrlyLNc4TCLxGicLAWk8Kwl3ooqI3ISVDzNbNtVkv8vSR3F7iwxbbkm1m3tuNSO9QohngDm+wIBPh1qHXfEc6vmmVpxg2a12p2yGMtJXM40zFsbAcPCn3Armdzud/Dxo1thIQn8fVJ9zdI6c6hmsluvVxwd1NgjNzZkeSxKMJz4ZaG3ErU0fPfbp47beNSu3uSXILLkyOiPIUgFxpLneBCvIK2G/3VhM9g36ZBgP4660JkGe3KUy64UJkNgKSpoqAO3EFdSCOVWPgzQfTNM1/j+c2CXjWa5XaLTIs+Swrfvc4L6OFSVtIWW1bePUjfkeXMVibfjGXZBpTaoNvs1gadW21OjXX25ftCXyQsvbhv41Hffn47VPLPi8q83i/XzI7Uzbvta3otvsaHQ6vuhxcS3FjkVHi2AHQJFYHDLRqrikEYhEZsk21x1FEG7SHlBTLJPIKaA3UoeA6etV4fc1dUcNw2aae5Y60Y9Dn5Pp49dWQq4SbgiFMeZcUnjRwEqSNugJ39edemp1mt2I2LH8Sxa1x2Yd7v6PaYrj60tvDh4ihSveISooQCPIbVnNTMfyy6XbEpNohw54sktMyQ7Ik9wXlAcPClISdtxud+nSslqjiErNcRjMsOItt6hvNzYThVxJZfT4EjqOZG+30o1zgRsXwJvb/wDTDRMbzN3Uez5KbZYrOxHZXGniJJWtUpkj3ElPAkHhIG3lWCxXEMbc1/y+I7aY70VuFGkCO8O8aLq9+JZSrcE+W/Tc7VNMRe1MnSYqMlhWe0x453kLjul5yWRy2SOjaT1J5nwrGWGyZdC1jvWTPWeD9lXRpqKCmdu62lro4U8Ox33Pu78uVdxwcUmlJNrj9y20xhsY/q/muN2xAYtXcxZzUZA2Qy4sEK4R4A7DlXnpbBi2/WvUViIyGmleyOFIJO6lJWpR5+ZJrJ2WyZVC1lvWRuWuEq0XNhqKHBM/KtpbB2XwcOx3JPLfyr5xCxZTbdWclvsu2QxaryWkocRM3caDSVBKinh58W/TflXEnt9TspJ9W/KX7GC0oxjG39QM9dfsFscXDvKPZiqKgln8mD7u493nz5VILk1j9kyu+rvD677PvqGy1bGoffvtsITw8Ow6N7kndXCN9+ZNeNos2YY1nmSSbZaYNxt99lNykSXJndezKCeFSVo4SVeY4a+otny6x6h5Lc7faYdzi33uVMy3ZfdmKW0FPAtOxUpPPccP8eXUsI5OXVJvPZfsefZodW5pXHQoucLU2U22hZ5oSHlbJ+lbNrW2neK5ZjuC3jGFvwo8nvH12+5NLKgtTpUoKU2R7nCT5n8KluCQbzbcRt0DIbgm4XRlkJkSB+efn47DYb+O29dhlJIq1HTKcpJ9zO0pSplApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQClKUApSlAKUpQH/9k="
    />
  </svg>
  <svg
    v-else-if="name === 'arrow-right'"
    xmlns="http://www.w3.org/2000/svg"
    width="162"
    height="49.281"
    viewBox="0 0 162 49.281"
  >
    <g id="Raggruppa_68" data-name="Raggruppa 68" transform="translate(-898 -787.362)">
      <g id="right-arrow" transform="translate(929.57 787.362)">
        <g id="Raggruppa_13" data-name="Raggruppa 13" transform="translate(101.478)">
          <path
            id="Tracciato_58"
            data-name="Tracciato 58"
            d="M129.644,22.717,107.713.787a2.7,2.7,0,0,0-3.813,0L102.286,2.4a2.7,2.7,0,0,0,0,3.813L120.7,24.63,102.265,43.066a2.7,2.7,0,0,0,0,3.813l1.615,1.614a2.7,2.7,0,0,0,3.813,0l21.951-21.95a2.721,2.721,0,0,0,0-3.826Z"
            transform="translate(-101.478)"
            fill="#822622"
          />
        </g>
      </g>
      <rect
        id="Rettangolo_123"
        data-name="Rettangolo 123"
        width="153"
        height="7"
        rx="3.5"
        transform="translate(898 809)"
        fill="#822622"
      />
    </g>
  </svg>
  <svg
    v-else-if="name === 'bordereaux'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      fill-rule="evenodd"
      d="M6 2a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2V7.414A2 2 0 0015.414 6L12 2.586A2 2 0 0010.586 2H6zm5 6a1 1 0 10-2 0v3.586l-1.293-1.293a1 1 0 10-1.414 1.414l3 3a1 1 0 001.414 0l3-3a1 1 0 00-1.414-1.414L11 11.586V8z"
      clip-rule="evenodd"
    />
  </svg>
  <svg
    v-else-if="name === 'cart'"
    xmlns="http://www.w3.org/2000/svg"
    class="h-6 w-6"
    viewBox="0 0 20 20"
    fill="currentColor"
  >
    <path
      d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z"
    />
  </svg>
  <svg
    v-else-if="name === 'medici'"
    id="cardiogram"
    xmlns="http://www.w3.org/2000/svg"
    width="71.821"
    height="64.806"
    viewBox="0 0 71.821 64.806"
  >
    <path
      id="Tracciato_65"
      data-name="Tracciato 65"
      d="M35.89,30.966C20.235,17.273.331,29.3,0,45.613a21.177,21.177,0,0,0,3.5,11.938h15.48l2.753-4.589a2.1,2.1,0,0,1,3.579-.047l5.809,9.129L39.6,44.167a2.106,2.106,0,0,1,3.754-.1l7.259,13.481H68.272C81.353,37.106,55.5,13.815,35.89,30.966Z"
      transform="translate(0 -25.006)"
      fill="#fff"
    />
    <path
      id="Tracciato_66"
      data-name="Tracciato 66"
      d="M89.412,212.187,83.53,201.263l-8.318,17.56a2.105,2.105,0,0,1-3.676.229l-6.027-9.471-1.615,2.691a2.1,2.1,0,0,1-1.8,1.021H48.746c.418.438-1.811-1.787,27.569,27.441a2.1,2.1,0,0,0,2.968,0c28.928-28.778,27.151-27,27.569-27.441H91.264a2.1,2.1,0,0,1-1.852-1.106Z"
      transform="translate(-41.909 -176.54)"
      fill="#fff"
    />
  </svg>
  <svg
    v-else-if="name === 'bancari'"
    id="bank"
    xmlns="http://www.w3.org/2000/svg"
    width="81.999"
    height="81.999"
    viewBox="0 0 81.999 81.999"
  >
    <path
      id="Tracciato_134"
      data-name="Tracciato 134"
      d="M79.757,447H2.562A3.266,3.266,0,0,0,0,449.883v5.125a2.4,2.4,0,0,0,2.4,2.4H79.6a2.4,2.4,0,0,0,2.4-2.4v-5.125A3.356,3.356,0,0,0,79.757,447Z"
      transform="translate(0 -375.411)"
      fill="#fff"
    />
    <path
      id="Tracciato_135"
      data-name="Tracciato 135"
      d="M80.518,16.2,41.92.184a2.4,2.4,0,0,0-1.841,0L1.482,16.2A2.4,2.4,0,0,0,0,18.418v4.8a2.4,2.4,0,0,0,2.4,2.4H79.6a2.4,2.4,0,0,0,2.4-2.4v-4.8A2.4,2.4,0,0,0,80.518,16.2Zm-25.1,2.219H26.586a2.4,2.4,0,0,1,0-4.8H55.414a2.4,2.4,0,1,1,0,4.8Z"
      transform="translate(0 -0.001)"
      fill="#fff"
    />
    <path
      id="Tracciato_136"
      data-name="Tracciato 136"
      d="M28.5,377.4v4.8H46.918v-4.8a2.4,2.4,0,0,0-2.4-2.4H30.9A2.4,2.4,0,0,0,28.5,377.4Z"
      transform="translate(-23.936 -314.942)"
      fill="#fff"
    />
    <path
      id="Tracciato_137"
      data-name="Tracciato 137"
      d="M48.5,190H60.512v24.824H48.5Z"
      transform="translate(-40.732 -159.571)"
      fill="#fff"
    />
    <path
      id="Tracciato_138"
      data-name="Tracciato 138"
      d="M388.5,190h12.012v24.824H388.5Z"
      transform="translate(-326.28 -159.571)"
      fill="#fff"
    />
    <path
      id="Tracciato_139"
      data-name="Tracciato 139"
      d="M368.5,377.4v4.8h18.418v-4.8a2.4,2.4,0,0,0-2.4-2.4H370.9A2.4,2.4,0,0,0,368.5,377.4Z"
      transform="translate(-309.483 -314.942)"
      fill="#fff"
    />
    <path
      id="Tracciato_140"
      data-name="Tracciato 140"
      d="M218.207,232.422a2.4,2.4,0,0,1-2.4-2.4,2.4,2.4,0,0,0-4.8,0,7.218,7.218,0,0,0,4.8,6.794v1.214a2.4,2.4,0,1,0,4.8,0v-1.214a7.206,7.206,0,0,0-2.4-14,2.4,2.4,0,1,1,2.4-2.4,2.4,2.4,0,0,0,4.8,0,7.218,7.218,0,0,0-4.8-6.794V212.4a2.4,2.4,0,0,0-4.8,0v1.214a7.206,7.206,0,0,0,2.4,14,2.4,2.4,0,1,1,0,4.8Z"
      transform="translate(-177.207 -176.368)"
      fill="#fff"
    />
  </svg>
  <svg
    v-else-if="name === 'paypal'"
    xmlns="http://www.w3.org/2000/svg"
    width="340.435"
    height="87"
    viewBox="0 0 340.435 87"
  >
    <g id="paypal_1_" data-name="paypal (1)" transform="translate(0 -187.6)">
      <path
        id="Tracciato_67"
        data-name="Tracciato 67"
        d="M375.84,221.2H357.467c-1.081,0-2.161,1.081-2.7,2.161L347.2,270.914a1.433,1.433,0,0,0,1.621,1.621h9.727a1.433,1.433,0,0,0,1.621-1.621L362.33,257.4a2.472,2.472,0,0,1,2.7-2.161h5.944q18.643,0,21.075-17.832c1.081-4.863,0-9.186-2.161-11.888-3.242-2.7-8.106-4.323-14.05-4.323M378,239.032c-1.081,6.484-5.944,6.484-10.807,6.484h-3.242l2.161-12.429c0-.54.54-1.081,1.621-1.081h1.081c3.242,0,6.484,0,8.106,2.161,1.081.54,1.081,2.161,1.081,4.863"
        transform="translate(-112.678 -10.904)"
        fill="#139ad6"
      />
      <g
        id="Raggruppa_24"
        data-name="Raggruppa 24"
        transform="translate(102.131 210.296)"
      >
        <path
          id="Tracciato_68"
          data-name="Tracciato 68"
          d="M179.84,221.2H161.467c-1.081,0-2.161,1.081-2.7,2.161L151.2,270.914a1.433,1.433,0,0,0,1.621,1.621h8.646c1.081,0,2.161-1.081,2.7-2.161L166.33,257.4a2.472,2.472,0,0,1,2.7-2.161h5.944q18.643,0,21.075-17.832c1.081-4.863,0-9.186-2.161-11.888-3.242-2.7-7.565-4.323-14.05-4.323M182,239.032c-1.081,6.484-5.944,6.484-10.807,6.484h-2.7l2.161-12.429c0-.54.54-1.081,1.621-1.081h1.081c3.242,0,6.484,0,8.106,2.161.54.54,1.081,2.161.54,4.863"
          transform="translate(-151.2 -221.2)"
          fill="#263b80"
        />
        <path
          id="Tracciato_69"
          data-name="Tracciato 69"
          d="M255.846,246.281H247.2c-.54,0-1.621.54-1.621,1.081l-.54,2.7-.54-1.081c-2.161-2.7-5.944-3.783-10.267-3.783-9.727,0-18.373,7.565-19.994,17.832a16.106,16.106,0,0,0,3.242,13.509c2.7,3.242,6.484,4.323,11.348,4.323A17.272,17.272,0,0,0,241.256,276l-.54,2.7a1.433,1.433,0,0,0,1.621,1.621h8.106c1.081,0,2.161-1.081,2.7-2.161l4.863-30.261c-.54-.54-1.621-1.621-2.162-1.621m-12.429,17.292c-1.081,4.863-4.863,8.646-10.267,8.646a8.641,8.641,0,0,1-5.944-2.161,11.524,11.524,0,0,1-1.621-6.484,9.638,9.638,0,0,1,15.671-6.484c1.621,1.621,2.161,4.323,2.161,6.484"
          transform="translate(-171.548 -228.989)"
          fill="#263b80"
        />
      </g>
      <path
        id="Tracciato_70"
        data-name="Tracciato 70"
        d="M451.046,246.281H442.4c-.54,0-1.621.54-1.621,1.081l-.54,2.7-.54-1.081c-2.161-2.7-5.944-3.783-10.267-3.783-9.727,0-18.373,7.565-19.994,17.832a16.106,16.106,0,0,0,3.242,13.509c2.7,3.242,6.484,4.323,11.348,4.323A17.272,17.272,0,0,0,436.456,276l-.54,2.7a1.433,1.433,0,0,0,1.621,1.621h8.106c1.081,0,2.161-1.081,2.7-2.161l4.863-30.261c-.54-.54-1.081-1.621-2.161-1.621m-12.429,17.292c-1.081,4.863-4.863,8.646-10.267,8.646a8.641,8.641,0,0,1-5.944-2.161,11.524,11.524,0,0,1-1.621-6.484,9.638,9.638,0,0,1,15.671-6.484,6.2,6.2,0,0,1,2.162,6.484"
        transform="translate(-132.766 -18.693)"
        fill="#139ad6"
      />
      <path
        id="Tracciato_71"
        data-name="Tracciato 71"
        d="M325.609,246.8h-9.186a2.807,2.807,0,0,0-2.161,1.081l-11.888,18.373-5.4-17.292a2.5,2.5,0,0,0-2.7-1.621h-8.646c-1.081,0-1.621,1.081-1.621,2.161l9.727,28.64-9.186,12.969c-.54,1.081,0,2.7,1.081,2.7h8.646a2.807,2.807,0,0,0,2.161-1.081l29.721-42.689c1.621-1.621.54-3.242-.54-3.242"
        transform="translate(-92.168 -19.212)"
        fill="#263b80"
      />
      <path
        id="Tracciato_72"
        data-name="Tracciato 72"
        d="M482.765,222.979,475.2,271.612a1.433,1.433,0,0,0,1.621,1.621h7.565c1.081,0,2.161-1.081,2.7-2.162l7.565-47.553a1.433,1.433,0,0,0-1.621-1.621h-8.646c-.54-.54-1.081,0-1.621,1.081"
        transform="translate(-154.218 -11.062)"
        fill="#139ad6"
      />
      <path
        id="Tracciato_73"
        data-name="Tracciato 73"
        d="M62.143,194.084c-3.783-4.323-10.807-6.484-20.534-6.484H14.59c-1.621,0-3.242,1.621-3.783,3.242L0,261.631a2.472,2.472,0,0,0,2.161,2.7H18.913l4.323-26.478v1.081c.54-1.621,2.161-3.242,3.783-3.242h8.106c15.671,0,27.559-6.484,31.342-24.317v-1.621h0c.54-7.025-.54-11.348-4.323-15.671"
        fill="#263b80"
      />
      <path
        id="Tracciato_74"
        data-name="Tracciato 74"
        d="M74.234,220.4h0v1.621c-3.783,18.373-15.671,24.317-31.342,24.317H34.786c-1.621,0-3.242,1.621-3.783,3.242l-5.4,32.963a1.979,1.979,0,0,0,2.161,2.161h14.05c1.621,0,3.242-1.081,3.242-2.7v-.54l2.7-16.752V263.63c0-1.621,1.621-2.7,3.242-2.7h2.161c13.509,0,24.317-5.4,27.019-21.615,1.081-6.484.54-12.429-2.7-16.211a5.534,5.534,0,0,0-3.242-2.7"
        transform="translate(-8.308 -10.645)"
        fill="#139ad6"
      />
      <path
        id="Tracciato_75"
        data-name="Tracciato 75"
        d="M73.307,217.221c-.54,0-1.081-.54-1.621-.54a1.985,1.985,0,0,1-1.621-.54,28.547,28.547,0,0,0-7.025-.54H41.965a1.985,1.985,0,0,0-1.621.54,2.972,2.972,0,0,0-1.621,2.7l-4.323,28.1v1.081c.54-1.621,2.161-3.242,3.783-3.242h8.106c15.671,0,27.559-6.484,31.342-24.317a1.985,1.985,0,0,1,.54-1.621c-1.081-.54-1.621-1.081-2.7-1.081-1.621-.54-1.621-.54-2.161-.54"
        transform="translate(-11.164 -9.087)"
        fill="#232c65"
      />
    </g>
  </svg>
</template>

<script>
export default {
  props: {
    name: String,
  },
};
</script>

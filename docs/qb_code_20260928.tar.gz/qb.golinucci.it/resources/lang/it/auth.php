<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Le credenziali non corrispondono a quanto presente nel nostro database.',
    'password' => 'La password fornita non è corretta.',
    'throttle' => 'Troppi tentativi falliti di login. Per favore provare di nuovo tra :seconds seconds.',

];

<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Password Reset Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are the default lines which match reasons
    | that are given by the password broker for a password update attempt
    | has failed, such as for an invalid token or invalid new password.
    |
    */

    'reset' => 'La tua password è stata resettata!',
    'sent' => 'Abbiamo inviato via email il link di reset della password!',
    'throttled' => 'Per favore attendere prima di ritentare.',
    'token' => 'Il token per il reset della password non è valido.',
    'user' => "Non esiste un utente con questo indirizzo email.",

];
